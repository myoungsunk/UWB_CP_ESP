# 현재 사용 펌웨어 소스 패키지

2026-11-10 KST 설치 및 운용 기록 기준입니다. 앞서 전달한 11월 7일 기준 ZIP을 대체합니다.

| 역할 | 패키지 기준 |
|---|---|
| 앵커 | R04/R1J, 11월 7일 설치 검증본의 소스와 역할별 DW1000Ng. 11월 10일 R04/R1J 및 R1L 동작 응답 확인. 앵커 플래시는 이번에 다시 읽지 않았습니다. |
| 태그 | R1K8_R1L80, 11월 10일 15:26 플래시 검증 및 이후 장치의 버전 응답 확인. 빌드 당시 소스 해시와 패키지 소스를 대조했습니다. |

11월 10일 Mode 6에서 ABA/BAB 5쌍, 총 10개 트랜잭션을 기록했습니다. 80 B 프로브 30개에 대해 전체 CIR 992샘플을 검증했습니다. 프로브 간격은 32 ms입니다. 수집은 커밋까지 확인됐고, 당시 앵커 데이터 파일은 내려받지 않았습니다. MODE6_REFERENCE.json은 해당 RF 설정과 결과 요약입니다.

## 로컬 빌드

ESP32 Arduino Core 3.3.7과 보드 esp32:esp32:esp32doit-devkit-v1을 사용합니다. 앵커와 태그는 각 폴더의 DW1000Ng를 사용합니다.

두 원본 바이너리에 장치 등록 키가 들어 있어 이 ZIP은 소스와 라이브러리만 담았습니다. 원본 앱 위치와 SHA-256, 빌드 시 필요한 역할별 키 헤더 위치는 PROVENANCE.json에 있습니다. 권한 있는 로컬 환경에서 해당 키 헤더를 스케치 폴더에 준비한 뒤, 압축을 푼 폴더에서 아래 명령을 실행합니다.

    arduino-cli compile --fqbn esp32:esp32:esp32doit-devkit-v1 --library anchor/vendor/DW1000Ng anchor/firmware/ANCHOR_RF_PLATFORM_V1
    arduino-cli compile --fqbn esp32:esp32:esp32doit-devkit-v1 --libraries tag/vendor tag/firmware/TAG_RF_PLATFORM_V1

PROVENANCE.json의 경로는 D:/SLAM_bot 기준입니다. 이번 전달 작업은 기존 설치·운용 증거의 대조와 소스 패키징입니다. 장치 상태와 기존 자료는 변경하지 않았습니다.
