#pragma once
#include <Arduino.h>
#include <SPI.h>
#include <soc/spi_reg.h>
#include <DW1000Ng.hpp>
#include <SPIporting.hpp>
#include <esp_timer.h>
#include <esp_system.h>
#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>
#include <freertos/task.h>
#include <atomic>
#include <stdarg.h>
#include <stdlib.h>
#include <ctype.h>
#include <new>
#include <Preferences.h>
#include <mbedtls/gcm.h>
#include "protocol.hpp"
#include "rx_guard_policy.hpp"
#include "diag_trace.hpp"

namespace bench {
constexpr bool IS_ANCHOR = BENCH_ANCHOR != 0;
constexpr uint8_t CS=21,RST=17,IRQ=22,CTRL=4,LS=5;
constexpr unsigned POOL_N=3, MAX_TX=5, MAX_RX=5;
constexpr uint32_t INITIAL_BAUD=921600;
static inline uint64_t nowUs(){return uint64_t(esp_timer_get_time());}
static const char* role(){return IS_ANCHOR?"anchor":"tag";}
static Config cfg;
static uint32_t bootId=0,sessionId=0,peerBoot=0;
static bool hwOK=false,active=false,rxArmed=false;
static bool tagRxFault=false,tagShutdownAttempted=false;
static tagdiag::Trace<96> tagDiag;
static uint8_t tagFaultReason=0,tagFaultStage=0;
static uint64_t tagFaultUs=0,tagFaultStatus=0,tagCheckTimeA=0,tagCheckTimeB=0;
static uint32_t tagCheckDev=0,tagValidatedResets=0;
static uint16_t tagCheckTx=0,tagCheckRx=0;
static void tagGuardTrip(uint8_t reason,uint64_t status,uint8_t stage);
static uint8_t route=0;
constexpr uint8_t R04_TAG_ROUTE_AUTO=2;
static uint8_t gR04TagResponseRouteOverride=R04_TAG_ROUTE_AUTO;
static uint8_t effectiveFastRouteForTxn(const Config& c,uint32_t txn){
  return gR04TagResponseRouteOverride<=ROUTE_B?gR04TagResponseRouteOverride:fastRouteForTxn(c,txn);
}
static uint8_t expectedTagRouteRuntime(uint8_t type,uint32_t txn){
  if(type==POLL||type==RESPONSE)return effectiveFastRouteForTxn(cfg,txn);
  return expectedTagRoute(cfg,txn,type);
}
static uint64_t switchAt=0,armedAt=0,armedHw=0,nextStart=0;
// R1F: WAIT4RESP after RESPONSE is a runtime A/B switch (RXW4R 0|1), default OFF.
static bool gTagW4R=false;static uint8_t gArmSource=0; // 0=software armRx, 1=hardware WAIT4RESP
// R1F: reason of the most recent pollPacket() rejection, captured BEFORE status is cleared.
// 1=RX_FAILED(PHE/FCE/RFSL/SFDTO/...),2=RX_TIMEOUT,3=BAD_LENGTH,4=DECODE,5=FOREIGN_SESSION_CONFIG_BOOT
static uint8_t gLastRejectCode=0;static uint64_t gLastRejectStatus=0,gLastRejectHw=0;
static uint32_t txnId=0,remaining=0,lastHeartbeat=0;
static std::atomic<uint32_t> currentBaud{INITIAL_BAUD};
static uint32_t txTimeouts=0,rxTimeouts=0,rxErrors=0,badAir=0,unexpected=0,periodMiss=0;
// RAWCAL audit: actual DW1000 antenna-delay register values after configuration.
static uint16_t antTxReadback=0,antRxReadback=0;static bool antReadbackOK=false;
static std::atomic<uint32_t> outputDrops{0},resourceDrops{0},sentRecords{0};
static std::atomic<bool> writerBusy{false};
static std::atomic<uint32_t> outputPending{0};
static QueueHandle_t outQ=nullptr,freeQ=nullptr;
static double ciHistPpm[3]{}; static uint8_t ciHistCount=0,ciHistPos=0;
static void resetCiHistory(){ciHistCount=0;ciHistPos=0;for(double &x:ciHistPpm)x=0;}
static double pushCiHistory(double ppm,uint32_t n){
  if(n<=1)return ppm;ciHistPpm[ciHistPos]=ppm;ciHistPos=(ciHistPos+1)%3;if(ciHistCount<3)++ciHistCount;
  double sum=0;for(uint8_t i=0;i<ciHistCount;i++)sum+=ciHistPpm[i];return sum/double(ciHistCount);
}

struct TxObs {
  uint8_t type=0,ctrl=255,ls=255;uint16_t bytes=0;bool ok=false;
  uint64_t planned=0,actual=0,status=0,begin_us=0,done_us=0;
  int32_t lead_start_us=0,lead_arm_us=0,tx_delta_ticks=0;
  uint32_t prepare_us=0,wait_us=0;
};
struct RxObs {
  uint8_t type=0,ctrl=0,ls=0;uint16_t bytes=0;
  int8_t cir_slot=-1;bool received=false,diag=false,settled=false,port_match=false;
  uint64_t hw=0,raw_hw=0,esp_us=0,arm_us=0,switch_us=0,status=0;
  int32_t arm_lead_us=-1000000000,preamble_margin_us=-1000000000;
  uint32_t fetch_us=0,diag_us=0,cir_us=0,compare_us=0,verify_us=0;
  int32_t detect_lag_us=0,observed_arm_to_rmarker_us=0;
  int32_t verify_bad=-1,verify_repeat_bad=-1,ci_raw=0;int64_t lde_adjust_ticks=0;bool lde_done=false;
  uint16_t fp_raw=0,nacc=0,cir_pwr=0,f1=0,f2=0,f3=0,noise=0;
  uint32_t ttcki=0;uint64_t ttcko=0;
  uint64_t tx_planned=0;uint32_t source_boot=0;
  // R1F wait diagnostics: first arm vs. last (re)arm and why the receiver was re-armed.
  int32_t first_arm_lead_us=-1000000000;uint16_t rearm_count=0,wait_rx_errors=0,wait_rejects=0,wait_unexpected=0;
  uint8_t last_reject_code=0,arm_source=0;uint64_t last_reject_status=0;int32_t last_reject_vs_expected_us=-1000000000;
  uint8_t raw_air[AIR_MAX_LEN]{};
};
struct Result {
  Config conf{};uint32_t session=0,txn=0,boot=0,peer=0;uint8_t fast_route=ROUTE_A;
  uint16_t ant_tx_requested=0,ant_rx_requested=0,ant_tx_readback=0,ant_rx_readback=0;bool ant_readback_ok=false;
  uint64_t begin_us=0,end_us=0;bool ok=false,fast_valid=false,aba_valid=false;
  char failure[40]{};uint8_t ntx=0,nrx=0,cir_mask=0;
  uint32_t bad_start=0,unexpected_start=0,rx_errors_start=0;
  double range_ci_inst=NAN,range_ci3=NAN,tof_ci_inst=NAN,tof_ci3=NAN;
  double ci_resp_ppm=NAN,ci_corr_ppm=NAN,ci3_corr_ppm=NAN;
  double aba_clock_ppm=NAN,delta_ba=NAN,range_b_inst=NAN,range_b_ci3=NAN;
  int32_t ci_resp_raw=0;uint8_t ci_hist_count=0;
  uint8_t ablk[R1L_BLOCK_BYTES]{};uint8_t ablk_copies=0;bool ablk_present=false,ablk_mismatch=false,ablk_used=false;
  uint64_t fast[4]{}; // TA1, RA1, TT, TR
  uint64_t aba_tx[3]{},aba_rx[3]{};
  double fp_spread_samples=NAN;bool fp_outlier=false;bool rx_w4r=false;
  TxObs tx[MAX_TX]{};RxObs rx[MAX_RX]{};
  uint8_t cir[3][CIR_BYTES]{};
};
static Result pool[POOL_N];
struct OutMsg {uint8_t kind=1,index=0;uint32_t baud=0;char text[1280]{};};
static void fail(Result& r,const char* why){if(!r.failure[0])snprintf(r.failure,sizeof(r.failure),"%s",why);r.ok=false;}

struct Json {
  char* p;size_t cap,n=0;bool ok=true;
  Json(char* b,size_t c):p(b),cap(c){if(c)p[0]=0;}
  void add(const char* fmt,...) __attribute__((format(printf,2,3))) {if(!ok)return;va_list a;va_start(a,fmt);int w=vsnprintf(p+n,cap-n,fmt,a);va_end(a);
    if(w<0||size_t(w)>=cap-n){ok=false;return;}n+=size_t(w);}
  void num(const char* key,double d,bool comma=true){add("\"%s\":",key);if(isfinite(d))add("%.12g",d);else add("null");if(comma)add(",");}
};
static void appendConfig(Json& j,const Config& c){
  uint32_t vals[CONFIG_FIELDS];memcpy(vals,&c,sizeof(c));j.add("{");
  for(unsigned i=0;i<CONFIG_FIELDS;i++)j.add("%s\"%s\":%lu",i?",":"",CONFIG_NAMES[i],(unsigned long)vals[i]);j.add("}");
}
static void event(const char* fmt,...) __attribute__((format(printf,1,2)));
static void event(const char* fmt,...){
  if(!outQ)return;OutMsg m;va_list a;va_start(a,fmt);int n=vsnprintf(m.text,sizeof(m.text),fmt,a);va_end(a);
  if(n<0||size_t(n)>=sizeof(m.text)){++outputDrops;return;}
  ++outputPending;
  if(xQueueSend(outQ,&m,0)!=pdTRUE){--outputPending;++outputDrops;}
}
static int reserveResult(uint32_t id){
  uint8_t i;if(xQueueReceive(freeQ,&i,0)!=pdTRUE){++resourceDrops;return -1;}
  // A completed slot is not reused until the writer has finished Serial.write.
  // Placement construction avoids a >12 kB Result temporary on the Arduino loop stack.
  new (&pool[i]) Result();auto& r=pool[i];r.conf=cfg;r.session=sessionId;r.txn=id;r.boot=bootId;r.peer=peerBoot;r.fast_route=(cfg.mode==4)?ROUTE_A:effectiveFastRouteForTxn(cfg,id);r.begin_us=nowUs();
  r.ant_tx_requested=r.ant_rx_requested=uint16_t(IS_ANCHOR?cfg.ant_anchor:cfg.ant_tag);r.ant_tx_readback=antTxReadback;r.ant_rx_readback=antRxReadback;r.ant_readback_ok=antReadbackOK;
  r.bad_start=badAir;r.unexpected_start=unexpected;r.rx_errors_start=rxErrors;return i;
}
static void submitResult(int i){
  auto& r=pool[i];r.end_us=nowUs();OutMsg m;m.kind=2;m.index=uint8_t(i);++outputPending;
  if(xQueueSend(outQ,&m,0)!=pdTRUE){--outputPending;++outputDrops;uint8_t b=uint8_t(i);xQueueSend(freeQ,&b,0);}
}
static uint16_t le16(const uint8_t* p){return uint16_t(p[0])|(uint16_t(p[1])<<8);}
static uint32_t le32(const uint8_t* p){return uint32_t(p[0])|(uint32_t(p[1])<<8)|(uint32_t(p[2])<<16)|(uint32_t(p[3])<<24);}
static uint64_t le40(const uint8_t* p){uint64_t x=0;for(unsigned i=0;i<5;i++)x|=uint64_t(p[i])<<(8*i);return x;}

// Same register-header encoding as the project library. Never read TX_BUFFER.
static void regRead(uint8_t reg,uint16_t off,uint8_t* dst,uint16_t n){
  byte h[3];uint8_t k=1;h[0]=reg&0x3F;
  if(off!=0xFFFF){h[0]|=0x40;h[k++]=off&0x7F;if(off>127){h[1]|=0x80;h[k++]=off>>7;}}
  SPIporting::readFromSPI(CS,k,h,n,dst);
}
static void regWrite(uint8_t reg,uint16_t off,uint8_t* src,uint16_t n){
  byte h[3];uint8_t k=1;h[0]=0x80|(reg&0x3F);
  if(off!=0xFFFF){h[0]|=0x40;h[k++]=off&0x7F;if(off>127){h[1]|=0x80;h[k++]=off>>7;}}
  SPIporting::writeToSPI(CS,k,h,n,src);
}
// Read the two physical DW1000 antenna-delay registers. TX_ANTD is register 0x18;
// LDE_RXANTD is subregister 0x1804 of LDE_IF (0x2E). Both are little-endian uint16.
static bool refreshAntennaDelayReadback(){
  uint8_t tx[2]{},rx[2]{};regRead(0x18,0xFFFF,tx,2);regRead(0x2E,0x1804,rx,2);
  antTxReadback=le16(tx);antRxReadback=le16(rx);
  const uint16_t requested=uint16_t(IS_ANCHOR?cfg.ant_anchor:cfg.ant_tag);
  antReadbackOK=(antTxReadback==requested&&antRxReadback==requested);return antReadbackOK;
}
static uint64_t status40(){uint8_t b[5];regRead(0x0F,0xFFFF,b,5);return le40(b);}
static uint64_t sysTime(){return DW1000Ng::getSystemTimestamp()&MASK40;}

// R1J6_E5_ARM_TRACE_V1 -- volatile one-shot ARM step tracing, Tag only.
// Level 1: timestamps + SPI write intercept; Level 2: same + intrusive SPI reads.
// Fixed-size RAM trace. NO RFB5 UART/event during critical ARM operations.
struct E5Snapshot {
  uint8_t stage, level, is_active, is_rx_armed, hw_good, gpio_ctrl, gpio_ls, gpio_cs;
  uint16_t tx, rx;
  uint32_t dev, write_seen;
  uint64_t stamp_us, sys;
};
struct E5Write {
  uint8_t stage, reg, nbytes, value0, value1, value2, value3;
  uint16_t off;
  uint64_t stamp_us;
};
static E5Snapshot e5Snapshots[20]{};
static E5Write e5Writes[24]{};
static uint8_t e5Level=0, e5Stage=0, e5N=0, e5WN=0;
static uint16_t e5SnapshotDrops=0, e5WriteDrops=0;
static uint32_t e5WriteCount=0, e5Session=0, e5Boot=0;
static bool e5InArm=false, e5Window=false, e5Captured=false;

static void e5ResetTrace(){
  e5N=e5WN=0;e5SnapshotDrops=e5WriteDrops=0;e5WriteCount=0;
  e5Stage=0;e5InArm=false;e5Window=false;e5Captured=false;
  e5Session=0;e5Boot=bootId;
}
static void e6ObserveWrite(const uint8_t*,uint8_t,const uint8_t*,uint16_t);
static void e5ObserveWrite(const uint8_t* h,uint8_t hn,const uint8_t* d,uint16_t dn){
  e6ObserveWrite(h,hn,d,dn);
  if(!e5Window||!e5Level||!h||hn<1||(h[0]&0x80U)==0)return;
  uint8_t reg=h[0]&0x3FU;
  // Watch writes that might modify TX_ANTD, LDE_RXANTD, PMSC, AON, or RF state.
  if(reg!=0x18&&reg!=0x2E&&reg!=0x36&&reg!=0x2C&&reg!=0x0D)return;
  uint16_t off=0xFFFFU;
  if((h[0]&0x40U)&&hn>=2){
    off=uint16_t(h[1]&0x7FU);
    if((h[1]&0x80U)&&hn>=3)off|=(uint16_t(h[2])<<7);
  }
  ++e5WriteCount;
  if(e5WN>=24){++e5WriteDrops;return;}
  E5Write &w=e5Writes[e5WN++];
  w.stage=e5Stage;w.reg=reg;w.off=off;
  w.nbytes=uint8_t(dn>255?255:dn);
  w.value0=(d&&dn>0)?d[0]:0;
  w.value1=(d&&dn>1)?d[1]:0;
  w.value2=(d&&dn>2)?d[2]:0;
  w.value3=(d&&dn>3)?d[3]:0;
  w.stamp_us=nowUs();
}
static void e5Snap(uint8_t stage){
  if(!e5Level||!e5InArm)return;
  e5Stage=stage;
  if(e5N>=20){++e5SnapshotDrops;return;}
  E5Snapshot &s=e5Snapshots[e5N++];
  s.stage=stage;s.level=e5Level;
  s.stamp_us=nowUs();s.is_active=active?1:0;
  s.is_rx_armed=rxArmed?1:0;s.hw_good=hwOK?1:0;
  s.gpio_ctrl=uint8_t(digitalRead(CTRL));
  s.gpio_ls=uint8_t(digitalRead(LS));
  s.gpio_cs=uint8_t(digitalRead(CS));
  s.write_seen=e5WriteCount;
  s.dev=0xFFFFFFFFUL;s.sys=0xFFFFFFFFFFULL;s.tx=s.rx=0xFFFFU;
  if(e5Level==2){
    uint8_t d[4]{},t[5]{},x[2]{},y[2]{};
    regRead(0x00,0xFFFF,d,4);regRead(0x06,0xFFFF,t,5);
    regRead(0x18,0xFFFF,x,2);regRead(0x2E,0x1804,y,2);
    s.dev=le32(d);s.sys=le40(t);s.tx=le16(x);s.rx=le16(y);
  }
}

// R1J6_E6_ROOT_CAUSE_V1: volatile, Tag-only investigation; never transmits RF.
// Time values are ESP monotonic micros, never compare raw DW1000 SYS_TIME
// without 40-bit wrap handling. The write observer sees SPIporting writes only.
struct E6Event {
  uint64_t us;
  uint32_t a,b;
  uint8_t code,arm_active,rx_armed;
};
static constexpr uint8_t E6_RING_CAP=96, E6_POST_CAP=32;
static E6Event e6Ring[E6_RING_CAP]{}, e6Post[E6_POST_CAP]{};
static uint8_t e6RingN=0,e6RingHead=0,e6PostN=0,e6Profile=0;
static bool e6Enabled=false,e6ArmedOnce=false,e6FirstBad=false,e6LowPending=false;
static uint8_t e6FirstActive=0,e6FirstRxArmed=0,e6FirstSource=0;
static uint32_t e6RingOverwrites=0,e6PostDrops=0,e6Polls=0,e6Rearms=0;
static uint32_t e6Done=0,e6Failed=0,e6Timeout=0,e6BadAir=0,e6Unexpected=0,e6Stale2s=0,e6HoldLoops=0;
static uint32_t e6TotalWrites=0,e6Sysctrl=0,e6Trxoff=0,e6Rxenab=0;
static uint32_t e6SoftLow=0,e6SoftHigh=0,e6SoftPairs=0,e6TxWrites=0,e6LdeWrites=0;
static uint32_t e6GoodSamples=0,e6BadSamples=0,e6FirstMask=0,e6LastRxStatusLo=0;
static uint32_t e6Session=0,e6FirstDev=0,e6FirstPolls=0,e6FirstRearms=0;
static uint32_t e6FirstSoftPairs=0,e6FirstTxWrites=0,e6FirstFailed=0,e6FirstTimeout=0;
static uint16_t e6FirstTx=0,e6FirstRx=0,e6LastTxWritten=0;
static uint64_t e6FirstSys=0,e6FirstUs=0,e6LastSoftUs=0,e6LastRearmUs=0;
static uint64_t e6FirstLastSoftUs=0,e6FirstLastRearmUs=0,e6LastTxWriteUs=0;
static uint64_t e6FirstLastTxWriteUs=0,e6LastSampleUs=0,e6LastSoftGapUs=0;
static uint64_t e6LastLowUs=0,e6FirstLastStatus=0;

// Event dictionary: 1 ARM_BEGIN, 2 ARM_DONE, 3 POLL_128, 4 RX_DONE,
// 5 RX_FAILED, 6 RX_TIMEOUT, 7 RX_REARM, 8 STALE_2S,
// 9 RX_RESET_E0, 10 RX_RESET_F0, 11 TX_ANTD_WRITE,
// 12 SYS_CTRL_TRXOFF, 13 SYS_CTRL_RXENAB, 14 BAD_AUDIT,
// 15 GOOD_AUDIT, 16 STOP, 17 HOLD_1024, 18 PMSC_OTHER, 19 RX_APP_REJECT.
static void e6Event(uint8_t code,uint32_t a=0,uint32_t b=0){
  if(!e6Enabled)return;
  E6Event e{nowUs(),a,b,code,uint8_t(active?1:0),uint8_t(rxArmed?1:0)};
  if(e6FirstBad){
    if(e6PostN<E6_POST_CAP)e6Post[e6PostN++]=e;
    else ++e6PostDrops;
    return;
  }
  if(e6RingN<E6_RING_CAP){e6Ring[(e6RingHead+e6RingN)%E6_RING_CAP]=e;++e6RingN;}
  else {e6Ring[e6RingHead]=e;e6RingHead=(e6RingHead+1)%E6_RING_CAP;++e6RingOverwrites;}
}
static void e6Reset(uint8_t p){
  e6Profile=p;e6Enabled=true;e6ArmedOnce=false;e6FirstBad=false;e6LowPending=false;
  e6RingN=e6RingHead=e6PostN=0;e6RingOverwrites=e6PostDrops=0;
  e6FirstActive=e6FirstRxArmed=e6FirstSource=0;
  e6Polls=e6Rearms=e6Done=e6Failed=e6Timeout=e6BadAir=e6Unexpected=e6Stale2s=e6HoldLoops=0;
  e6TotalWrites=e6Sysctrl=e6Trxoff=e6Rxenab=0;
  e6SoftLow=e6SoftHigh=e6SoftPairs=e6TxWrites=e6LdeWrites=0;
  e6GoodSamples=e6BadSamples=e6FirstMask=e6LastRxStatusLo=0;
  e6Session=e6FirstDev=e6FirstPolls=e6FirstRearms=0;
  e6FirstSoftPairs=e6FirstTxWrites=e6FirstFailed=e6FirstTimeout=0;
  e6FirstTx=e6FirstRx=e6LastTxWritten=0;
  e6FirstSys=e6FirstUs=e6LastSoftUs=e6LastRearmUs=0;
  e6FirstLastSoftUs=e6FirstLastRearmUs=e6LastTxWriteUs=0;
  e6FirstLastTxWriteUs=e6LastSampleUs=e6LastSoftGapUs=e6LastLowUs=e6FirstLastStatus=0;
}
static bool e6HoldMode(){return e6Enabled && (e6Profile==3 || e6Profile==4);}
static bool e6PeriodicMode(){return e6Enabled && (e6Profile==2 || e6Profile==4);}
static void e6OnArm(uint32_t sid){
  if(!e6Enabled)return;
  e6Session=sid;e6ArmedOnce=true;e6LastSampleUs=nowUs();e6Event(1,sid,e6Profile);
}
static void e6OnArmDone(){e6Event(2,e6Rearms,e6Polls);}
static void e6OnStop(){e6Event(16,e6Polls,e6SoftPairs);}
static void e6OnRearm(){
  if(!e6Enabled)return;
  ++e6Rearms;e6LastRearmUs=nowUs();e6Event(7,e6Rearms,e6Polls);
}
static void e6OnPoll(){
  if(!e6Enabled)return;
  ++e6Polls;
  if((e6Polls&127U)==0U)e6Event(3,e6Polls,e6SoftPairs);
}
static void e6OnRxDone(){if(e6Enabled){++e6Done;e6Event(4,e6Done,e6Polls);}}
static void e6OnRxError(uint8_t code,uint64_t status){
  if(!e6Enabled)return;
  e6LastRxStatusLo=uint32_t(status);
  if(code==1){++e6Failed;e6Event(5,e6LastRxStatusLo,uint32_t(status>>32));}
  else {++e6Timeout;e6Event(6,e6LastRxStatusLo,uint32_t(status>>32));}
}
static void e6OnRejected(uint8_t code,uint64_t status){
  if(!e6Enabled)return;
  e6LastRxStatusLo=uint32_t(status);
  if(code==5)++e6Unexpected;else ++e6BadAir;
  e6Event(19,code,e6LastRxStatusLo);
}
static void e6OnHold(){
  if(!e6Enabled)return;
  ++e6HoldLoops;
  if((e6HoldLoops&1023U)==0U)e6Event(17,e6HoldLoops,0);
}
static void e6OnStale(){if(e6Enabled){++e6Stale2s;e6Event(8,e6Stale2s,e6Polls);}}
// Hooked into E5's SPIporting observer *before* E5's 24-write cap.
// Counters do not saturate at 24; only the bounded event window overwrites.
static void e6ObserveWrite(const uint8_t* h,uint8_t hn,const uint8_t* d,uint16_t dn){
  if(!e6Enabled||!h||hn<1||!(h[0]&0x80U))return;
  ++e6TotalWrites;
  const uint8_t reg=h[0]&0x3FU;
  uint16_t off=0xFFFFU;
  if((h[0]&0x40U)&&hn>=2){
    off=uint16_t(h[1]&0x7FU);
    if((h[1]&0x80U)&&hn>=3)off|=uint16_t(h[2])<<7;
  }
  const uint8_t b=dn&&d?d[0]:0;
  if(reg==0x18){
    ++e6TxWrites;e6LastTxWriteUs=nowUs();
    e6LastTxWritten=uint16_t(b)|uint16_t(dn>=2&&d?d[1]:0)<<8;
    e6Event(11,e6LastTxWritten,uint32_t(off));
  } else if(reg==0x2E){++e6LdeWrites;}
  else if(reg==0x0D){
    ++e6Sysctrl;
    if(b&0x40U){++e6Trxoff;if((e6Trxoff&31U)==1U)e6Event(12,e6Trxoff,e6Polls);}
    if(d && dn>1 && (d[1]&1U)){
      ++e6Rxenab;if((e6Rxenab&31U)==1U)e6Event(13,e6Rxenab,e6Polls);
    }
  } else if(reg==0x36){
    if(off==3 && dn){
      if(b==0xE0){
        ++e6SoftLow;e6LowPending=true;e6LastLowUs=nowUs();
        e6Event(9,e6SoftLow,e6LastRxStatusLo);
      } else if(b==0xF0){
        ++e6SoftHigh;e6LastSoftUs=nowUs();
        if(e6LowPending){++e6SoftPairs;e6LastSoftGapUs=e6LastSoftUs-e6LastLowUs;}
        e6LowPending=false;
        e6Event(10,e6SoftPairs,uint32_t(e6LastSoftGapUs));
      } else e6Event(18,uint32_t(off),b);
    }
  }
}
// Snapshot the bytes already read by SPIAUDIT, no additional DW1000 access.
// No claim of electrical simultaneity: each register is read sequentially.
static void e6AuditCapture(uint32_t mhz,const uint8_t*dev,const uint8_t*tm,
                           const uint8_t*tx,const uint8_t*rx,const uint8_t*stat,
                           uint8_t source){
  if(!e6Enabled||!e6ArmedOnce)return;
  const uint32_t dv=le32(dev);
  const uint64_t ts=le40(tm),ss=le40(stat);
  const uint16_t x=le16(tx),y=le16(rx);
  const uint32_t bad=(dv!=0xDECA0130UL?1U:0U)|(x!=16436U?2U:0U)|
                     (y!=16436U?4U:0U)|((ts==0||ts==0xFFFFFFFFFFULL)?8U:0U);
  if(bad){
    ++e6BadSamples;
    if(!e6FirstBad){
      e6Event(14,bad,(uint32_t(mhz)&0xFFU)|(uint32_t(source)<<8));
      e6FirstBad=true;e6FirstMask=bad;e6FirstUs=nowUs();
      e6FirstActive=active?1:0;e6FirstRxArmed=rxArmed?1:0;e6FirstSource=source;
      e6FirstDev=dv;e6FirstSys=ts;e6FirstTx=x;e6FirstRx=y;
      e6FirstPolls=e6Polls;e6FirstRearms=e6Rearms;
      e6FirstSoftPairs=e6SoftPairs;e6FirstTxWrites=e6TxWrites;
      e6FirstFailed=e6Failed;e6FirstTimeout=e6Timeout;
      e6FirstLastSoftUs=e6LastSoftUs;e6FirstLastRearmUs=e6LastRearmUs;
      e6FirstLastTxWriteUs=e6LastTxWriteUs;e6FirstLastStatus=ss;
    }
    tagGuardTrip(3,ss,4);
  } else {++e6GoodSamples;if((e6GoodSamples&15U)==1U)e6Event(15,e6GoodSamples,uint32_t(source));}
}
// Instrumented profile only. Passive profiles never add periodic SPI reads.
static void e6Periodic(){
  if(tagRxFault||!e6PeriodicMode()||!e6ArmedOnce||!active||e6FirstBad)return;
  const uint64_t t=nowUs();
  if(t-e6LastSampleUs<25000ULL)return;  // 25 ms bounded cadence
  e6LastSampleUs=t;
  uint8_t d[4]{},tm[5]{},x[2]{},y[2]{},s[5]{};
  regRead(0x00,0xFFFF,d,4);regRead(0x06,0xFFFF,tm,5);
  regRead(0x18,0xFFFF,x,2);regRead(0x2E,0x1804,y,2);
  regRead(0x0F,0xFFFF,s,5);
  e6AuditCapture(20,d,tm,x,y,s,2);
}

#include "post_fault.hpp"
#include "diag_impl.hpp"
#include "rx_guard_impl.hpp"
static void idleRadio(){if(tagRxFault){rxArmed=false;return;}DW1000Ng::forceTRxOff();tagClearMask(rxguard::RX_CLEAR|rxguard::TX_CLEAR);rxArmed=false;}
static void selectRoute(uint8_t r){
  if(IS_ANCHOR)return;
  r&=1U;
  if(r!=route){if(rxArmed){DW1000Ng::forceTRxOff();rxArmed=false;}
    digitalWrite(LS,LOW);digitalWrite(CTRL,r?LOW:HIGH);route=r;switchAt=nowUs();}
  else digitalWrite(LS,LOW);
}
static void waitSwitch(){if(IS_ANCHOR)return;while(nowUs()-switchAt<cfg.switch_us)delayMicroseconds(5);}
static uint32_t searchGapUs=0,searchSettleUs=0;
static bool armRxEnableBit=true;
static void armRx(){
  SPIporting::RxSpeedScope rxSpeed(!IS_ANCHOR);
  if(tagRxFault||rxArmed)return;
  if(!tagGuardCheck(1,0))return;waitSwitch();
  DW1000Ng::forceTRxOff();e5Snap(6);
  tagClearMask(rxguard::RX_CLEAR);e5Snap(7);
  SPIporting::setSPIspeed(SPIClock::FAST);e5Snap(8);
  DW1000Ng::startReceive(ReceiveMode::IMMEDIATE,armRxEnableBit);
  if(!IS_ANCHOR&&searchSettleUs)delayMicroseconds(searchSettleUs);
  e5Snap(9);
  rxArmed=true;armedAt=nowUs();armedHw=sysTime();e5Snap(10);gArmSource=0;
  tagGuardCheck(6,0); // immediate post-RX-enable readback
}
static bool healthy(){
  SPIporting::setSPIspeed(SPIClock::FAST);for(unsigned i=0;i<5;i++){uint8_t b[4];regRead(0,0xFFFF,b,4);if(le32(b)!=0xDECA0130UL)return false;}
  uint64_t a=sysTime();delay(3);uint64_t d=delta40(sysTime(),a);return d>usTicks(1000)&&d<usTicks(30000);
}
static bool applyRadio(){
  idleRadio();
  device_configuration_t c={false,false,true,true,false,SFDMode::STANDARD_SFD,Channel::CHANNEL_5,
    cfg.rate_kbps==850?DataRate::RATE_850KBPS:DataRate::RATE_6800KBPS,
    PulseFrequency::FREQ_16MHZ,cfg.preamble==256?PreambleLength::LEN_256:PreambleLength::LEN_128,PreambleCode::CODE_3};
  DW1000Ng::applyConfiguration(c);DW1000Ng::setNetworkId(10);DW1000Ng::setDeviceAddress(IS_ANCHOR?5:6);
  DW1000Ng::setAntennaDelay(uint16_t(IS_ANCHOR?cfg.ant_anchor:cfg.ant_tag));
  DW1000Ng::setWait4Response(0);DW1000Ng::setDoubleBuffering(false);
  // This writes the library SYS_CFG cache, including DIS_DRXB.
  DW1000Ng::setReceiveFrameWaitTimeoutPeriod(0);SPIporting::setSPIspeed(SPIClock::FAST);
  // RAWCAL: audit the effective TX/RX antenna-delay registers immediately after programming.
  refreshAntennaDelayReadback();
  if(!IS_ANCHOR){pinMode(LS,OUTPUT);pinMode(CTRL,OUTPUT);digitalWrite(LS,LOW);digitalWrite(CTRL,HIGH);route=0;switchAt=nowUs();}
  const bool radioOK=healthy();return radioOK&&antReadbackOK;
}

static uint8_t acc[CIR_BYTES+1],compareBuf[CIR_BYTES],repeatBuf[CIR_BYTES];
static uint32_t cirReadOnce(uint8_t* dst,bool block){
  uint64_t start=nowUs();uint8_t old[2],on[2];regRead(0x36,0,old,2);
  on[0]=(old[0]&0xB3)|0x48;on[1]=old[1]|0x80;regWrite(0x36,0,on,2);
  if(!block&&cfg.cir_hz==20000000){regRead(0x25,0xFFFF,acc,CIR_BYTES+1);}
  else {
    SPIporting::beginExternalTransaction(cfg.cir_hz);digitalWrite(CS,LOW);
    SPI.transfer(uint8_t(0x25));
    if(block)SPI.transferBytes(nullptr,acc,CIR_BYTES+1);
    else for(unsigned i=0;i<CIR_BYTES+1;i++)acc[i]=SPI.transfer(uint8_t(0));
    delayMicroseconds(5);digitalWrite(CS,HIGH);SPIporting::endExternalTransaction();
  }
  regWrite(0x36,0,old,2);memcpy(dst,acc+1,CIR_BYTES);return uint32_t(nowUs()-start);
}
static int firstMismatch(const uint8_t* a,const uint8_t* b){for(unsigned i=0;i<CIR_BYTES;i++)if(a[i]!=b[i])return int(i);return -1;}
static void captureCir(Result& r,RxObs& o,unsigned slot){
  o.cir_slot=int8_t(slot);o.cir_us=cirReadOnce(r.cir[slot],cfg.cir_backend==1);
  if(cfg.verify_cir){
    // Same received accumulator, no new RX between the three reads.
    o.compare_us=cirReadOnce(compareBuf,cfg.cir_backend==0);
    o.verify_us=cirReadOnce(repeatBuf,cfg.cir_backend==1);
    o.verify_bad=firstMismatch(r.cir[slot],compareBuf);o.verify_repeat_bad=firstMismatch(r.cir[slot],repeatBuf);
    if(o.verify_bad>=0||o.verify_repeat_bad>=0)fail(r,"CIR_BYTE_BLOCK_COMPARE");
  }
  r.cir_mask|=uint8_t(1U<<slot);
}
static void diagnostics(RxObs& o){
  uint64_t start=nowUs();uint8_t fi[4],fq[8],rt[14],ci[3],cki[4],cko[5];
  if(!o.status)o.status=status40();regRead(0x10,0xFFFF,fi,4);regRead(0x12,0xFFFF,fq,8);
  regRead(0x15,0xFFFF,rt,14);regRead(0x27,0x28,ci,3);regRead(0x13,0xFFFF,cki,4);regRead(0x14,0xFFFF,cko,5);
  o.fp_raw=le16(rt+5);o.f1=le16(rt+7);o.noise=le16(fq);o.f2=le16(fq+2);o.f3=le16(fq+4);o.cir_pwr=le16(fq+6);
  o.nacc=uint16_t((fi[2]>>4)|(uint16_t(fi[3])<<4));
  uint32_t cr=uint32_t(ci[0])|(uint32_t(ci[1])<<8)|(uint32_t(ci[2])<<16);cr&=0x1FFFFFUL;
  o.ci_raw=(cr&0x100000UL)?int32_t(cr)-0x200000L:int32_t(cr);
  o.ttcki=le32(cki);o.ttcko=le40(cko);o.diag=true;o.diag_us=uint32_t(nowUs()-start);
}
static void finishRx(){SPIporting::RxSpeedScope rxSpeed(!IS_ANCHOR);if(!tagRxFault)tagClearMask(rxguard::RX_CLEAR);rxArmed=false;}
// Returns 1: valid app frame, 0: none, -1: event rejected/error and receiver needs rearming.
static int pollPacket(AirPacket& p,RxObs& o){
  SPIporting::RxSpeedScope rxSpeed(!IS_ANCHOR);
  if(tagRxFault)return -1;
  if(e6HoldMode()){e6OnHold();return 0;}
  e6OnPoll();
  if(!rxArmed){e6OnRearm();armRx();}
  if(tagRxFault)return -1;
  const uint64_t rxStatus=status40(); // one status snapshot for this decision
  if(rxStatus){tagDiagMarker(tagdiag::RxStatus,0,rxStatus);}
  const auto action=rxguard::classify(rxStatus);
  if(action==rxguard::Action::Untrusted || action==rxguard::Action::ClockFault || action==rxguard::Action::Overrun || action==rxguard::Action::FilterReject){tagGuardTrip(1,rxStatus,1);return -1;}
  if(action==rxguard::Action::Failed){tagRecoverRx(rxStatus,1);return -1;}
  if(action==rxguard::Action::Timeout){tagRecoverRx(rxStatus,2);return -1;}
  if(action==rxguard::Action::Done){
    if(!tagGuardCheck(5,rxStatus))return -1;
    e6OnRxDone();
    uint64_t s=nowUs();o.esp_us=s;o.arm_us=armedAt;o.switch_us=switchAt;
    o.bytes=DW1000Ng::getReceivedDataLength();o.hw=DW1000Ng::getReceiveTimestamp()&MASK40;
    o.raw_hw=DW1000Ng::getReceiveTimestampRaw()&MASK40;o.lde_adjust_ticks=signed40(o.hw,o.raw_hw);
    o.status=rxStatus;o.lde_done=(o.status&(1ULL<<10))!=0;
    // Always capture the 21-bit carrier integrator for the one-shot clock/timestamp audit.
    uint8_t ciAudit[3];regRead(0x27,0x28,ciAudit,3);
    uint32_t crAudit=uint32_t(ciAudit[0])|(uint32_t(ciAudit[1])<<8)|(uint32_t(ciAudit[2])<<16);crAudit&=0x1FFFFFUL;
    o.ci_raw=(crAudit&0x100000UL)?int32_t(crAudit)-0x200000L:int32_t(crAudit);
    o.detect_lag_us=int32_t(ticksUs(signed40(sysTime(),o.hw)));
    o.observed_arm_to_rmarker_us=int32_t(ticksUs(signed40(o.hw,armedHw)));
    o.ctrl=IS_ANCHOR?255:uint8_t(digitalRead(CTRL));o.ls=IS_ANCHOR?255:uint8_t(digitalRead(LS));
    o.settled=IS_ANCHOR||(armedAt>=switchAt&&armedAt-switchAt>=cfg.switch_us);
    if(o.bytes<36||o.bytes>sizeof(o.raw_air)){++badAir;gLastRejectCode=3;gLastRejectStatus=o.status;e6OnRejected(3,o.status);gLastRejectHw=sysTime();finishRx();return -1;}
    DW1000Ng::getReceivedData(o.raw_air,o.bytes);
    if(!decodeAir(o.raw_air,o.bytes,p)){++badAir;gLastRejectCode=4;gLastRejectStatus=o.status;e6OnRejected(4,o.status);gLastRejectHw=sysTime();finishRx();return -1;}
    if(p.h.session!=sessionId||p.h.config_id!=configId(cfg)||p.h.boot!=peerBoot){++unexpected;gLastRejectCode=5;gLastRejectStatus=o.status;e6OnRejected(5,o.status);gLastRejectHw=sysTime();finishRx();return -1;}
    o.received=true;o.type=p.h.type;o.tx_planned=p.ts[p.h.type==RESPONSE?1:0];o.source_boot=p.h.boot;
    o.port_match=IS_ANCHOR||(route==expectedTagRouteRuntime(p.h.type,p.h.txn));o.fetch_us=uint32_t(nowUs()-s);
    // Do not clear status until the caller has snapshotted diagnostics/CIR.
    return 1;
  }
  return 0;
}
static void r1fStampWait(RxObs& o,int32_t firstLead,uint16_t rearms,uint16_t errs,uint16_t rejects,uint16_t unexp,uint8_t rcode,uint64_t rstatus,int32_t rvs){
  o.first_arm_lead_us=firstLead;o.rearm_count=rearms;o.wait_rx_errors=errs;o.wait_rejects=rejects;o.wait_unexpected=unexp;
  o.last_reject_code=rcode;o.last_reject_status=rstatus;o.last_reject_vs_expected_us=rvs;o.arm_source=gArmSource;
}
static bool waitPacket(uint8_t typ,uint32_t id,uint64_t expected,AirPacket& p,RxObs& o,Result& r){
  armRx();int64_t lead=signed40(expected,sysTime());
  uint64_t deadline=nowUs()+uint64_t(lead>0?ticksUs(lead):0)+cfg.rx_grace_us;
  int32_t armLead=int32_t(ticksUs(signed40(expected,armedHw)));
  // R1F: the initial arm lead is kept separately; arm_lead_us stays "last (re)arm" for R04 compatibility.
  const int32_t firstLead=armLead;uint16_t rearms=0,errs=0,rejects=0,unexp=0;uint8_t rcode=0;uint64_t rstatus=0;int32_t rvs=-1000000000;
  while(nowUs()<deadline){
    if(tagRxFault){fail(r,"TAG_RX_GUARD_LATCHED");return false;}
    RxObs candidate{};AirPacket q{};gLastRejectCode=0;int got=pollPacket(q,candidate);
    if(got==1){
      if(q.h.type==typ&&q.h.txn==id){p=q;o=candidate;armLead=int32_t(ticksUs(signed40(expected,armedHw)));o.arm_lead_us=armLead;o.preamble_margin_us=armLead-int32_t(cfg.rx_guard_us);
        r1fStampWait(o,firstLead,rearms,errs,rejects,unexp,rcode,rstatus,rvs);return true;}
      ++unexpected;++unexp;rcode=6;rstatus=candidate.status;rvs=int32_t(ticksUs(signed40(sysTime(),expected)));finishRx();armRx();++rearms;
    } else if(got<0){
      if(gLastRejectCode==1||gLastRejectCode==2)++errs;else ++rejects;
      rcode=gLastRejectCode;rstatus=gLastRejectStatus;rvs=int32_t(ticksUs(signed40(gLastRejectHw,expected)));armRx();++rearms;
    }
    delayMicroseconds(10);
  }
  ++rxTimeouts;
  RxObs miss{};miss.type=typ;miss.esp_us=nowUs();miss.arm_us=armedAt;miss.switch_us=switchAt;miss.status=status40();
  miss.arm_lead_us=int32_t(ticksUs(signed40(expected,armedHw)));miss.preamble_margin_us=miss.arm_lead_us-int32_t(cfg.rx_guard_us);
  miss.ctrl=IS_ANCHOR?255:uint8_t(digitalRead(CTRL));miss.ls=IS_ANCHOR?255:uint8_t(digitalRead(LS));
  miss.settled=IS_ANCHOR||(armedAt>=switchAt&&armedAt-switchAt>=cfg.switch_us);
  miss.port_match=IS_ANCHOR||(route==expectedTagRouteRuntime(typ,id));
  r1fStampWait(miss,firstLead,rearms,errs,rejects,unexp,rcode,rstatus,rvs);
  if(r.nrx<MAX_RX)r.rx[r.nrx++]=miss;
  idleRadio();char reason[40];snprintf(reason,sizeof(reason),"RX_TIMEOUT_%s",typeName(typ));fail(r,reason);return false;
}
static bool sendDelayedPacket(uint8_t typ,uint32_t id,uint64_t requested,TxObs& o,const uint64_t* responseTimes=nullptr){
  if(tagRxFault)return false;
  o.type=typ;o.begin_us=nowUs();o.ctrl=IS_ANCHOR?255:uint8_t(digitalRead(CTRL));o.ls=IS_ANCHOR?255:uint8_t(digitalRead(LS));
  if(!IS_ANCHOR){uint8_t required=(typ==RESPONSE)?effectiveFastRouteForTxn(cfg,id):ROUTE_A;if(route!=required||digitalRead(LS)!=LOW)return false;}
  waitSwitch();uint16_t ant=uint16_t(IS_ANCHOR?cfg.ant_anchor:cfg.ant_tag);
  uint64_t dx=((requested-ant)&MASK40)&~511ULL;o.planned=(dx+ant)&MASK40;
  AirPacket p{};p.h.type=typ;p.h.session=sessionId;p.h.txn=id;p.h.config_id=configId(cfg);p.h.boot=bootId;
  if(typ==RESPONSE&&responseTimes){p.ts[0]=responseTimes[0];p.ts[1]=o.planned;}else p.ts[0]=o.planned;
  byte data[54]{};o.bytes=uint16_t(encodeAir(p,data));
  idleRadio();uint8_t clr[5]{};clr[3]=0x08;clr[4]=0x04;regWrite(0x0F,0xFFFF,clr,5);
  uint64_t prep=nowUs();o.lead_start_us=int32_t(ticksUs(signed40(dx,sysTime())));
  if(o.lead_start_us<int32_t(cfg.min_lead_us)){o.status=status40();return false;}
  byte d[5];for(unsigned i=0;i<5;i++)d[i]=byte(dx>>(8*i));
  DW1000Ng::setDelayedTRX(d);DW1000Ng::setTransmitData(data,o.bytes);
  o.lead_arm_us=int32_t(ticksUs(signed40(dx,sysTime())));o.prepare_us=uint32_t(nowUs()-prep);
  if(o.lead_arm_us<int32_t(cfg.min_lead_us)){idleRadio();return false;}
  // R1F: WAIT4RESP is an opt-in A/B experiment (RXW4R 1). R1E made it default
  // based on B1 arm_lead_us=-328 us, but that value is the LAST re-arm after an
  // RX rejection; the first arm was ~+4.8 ms early (see R1F handoff, section 2).
  const bool autoRxAfterResponse=(gTagW4R && !IS_ANCHOR && typ==RESPONSE && cfg.mode!=3);
  if(autoRxAfterResponse)DW1000Ng::setWait4Response(cfg.switch_us);
  DW1000Ng::startTransmit(TransmitMode::DELAYED);
  uint64_t startWait=nowUs();uint64_t timeout=uint64_t(o.lead_arm_us)+cfg.rx_grace_us+2000;
  while(!DW1000Ng::isTransmitDone()){
    if(nowUs()-startWait>timeout){++txTimeouts;o.status=status40();idleRadio();o.wait_us=uint32_t(nowUs()-startWait);o.done_us=nowUs();return false;}
    delayMicroseconds(10);
  }
  o.actual=DW1000Ng::getTransmitTimestamp()&MASK40;o.status=status40();o.tx_delta_ticks=int32_t(signed40(o.actual,o.planned));
  o.done_us=nowUs();o.wait_us=uint32_t(nowUs()-startWait);tagClearTxStatus();
  o.ok=o.tx_delta_ticks==0&&!(o.status&(1ULL<<27))&&!(o.status&(1ULL<<34));
  if(autoRxAfterResponse && o.ok){
    // Hardware RX is enabled W4R_TIM (~switch_us) after TX end. Report the
    // upper bound of that instant, not the software observation time.
    rxArmed=true;armedAt=nowUs()+cfg.switch_us;armedHw=(sysTime()+usTicks(uint64_t(cfg.switch_us)+3))&MASK40;gArmSource=1;
  }else if(autoRxAfterResponse){
    DW1000Ng::setWait4Response(0);
  }
  return o.ok;
}
static bool sendImmediatePoll(uint32_t id,TxObs& o){
  o.type=POLL;o.begin_us=nowUs();o.ctrl=255;o.ls=255;if(!IS_ANCHOR)return false;
  AirPacket p{};p.h.type=POLL;p.h.session=sessionId;p.h.txn=id;p.h.config_id=configId(cfg);p.h.boot=bootId;p.ts[0]=0;
  byte data[54]{};o.bytes=uint16_t(encodeAir(p,data));idleRadio();DW1000Ng::setTransmitData(data,o.bytes);
  uint64_t startWait=nowUs();DW1000Ng::startTransmit(TransmitMode::IMMEDIATE);
  while(!DW1000Ng::isTransmitDone()){
    if(nowUs()-startWait>cfg.rx_grace_us+5000){++txTimeouts;o.status=status40();idleRadio();o.done_us=nowUs();return false;}
    delayMicroseconds(10);
  }
  o.actual=DW1000Ng::getTransmitTimestamp()&MASK40;o.planned=o.actual;o.tx_delta_ticks=0;o.status=status40();o.done_us=nowUs();o.wait_us=uint32_t(o.done_us-startWait);o.ok=true;tagClearTxStatus();return true;
}

static bool sendSessionStartPacket(uint32_t count,unsigned burst_index){
  if(tagRxFault||IS_ANCHOR||!sessionId||!peerBoot||count<1||count>1000000)return false;
  idleRadio();selectRoute(0);waitSwitch();
  AirPacket p{};p.h.type=SESSION_START;p.h.session=sessionId;p.h.txn=0;p.h.config_id=configId(cfg);p.h.boot=bootId;p.ts[0]=uint64_t(count);
  byte data[54]{};uint16_t n=uint16_t(encodeAir(p,data));DW1000Ng::setTransmitData(data,n);
  uint64_t startWait=nowUs();DW1000Ng::startTransmit(TransmitMode::IMMEDIATE);
  while(!DW1000Ng::isTransmitDone()){
    if(nowUs()-startWait>cfg.rx_grace_us+5000){++txTimeouts;idleRadio();return false;}
    delayMicroseconds(10);
  }
  uint64_t txhw=DW1000Ng::getTransmitTimestamp()&MASK40;uint64_t st=status40();
  char airHex[109]{};for(unsigned i=0;i<n&&i<54;i++)snprintf(airHex+2*i,3,"%02x",data[i]);
  event("{\"event\":\"SESSION_START_TX\",\"role\":\"tag\",\"session\":%lu,\"burst_index\":%u,\"count\":%lu,\"tx_hw\":%llu,\"bytes\":%u,\"air_crc32\":%lu,\"status\":%llu,\"air_hex\":\"%s\"}",
    (unsigned long)sessionId,burst_index,(unsigned long)count,(unsigned long long)txhw,unsigned(n),(unsigned long)crc32(data,n),(unsigned long long)st,airHex);
  tagClearTxStatus();idleRadio();return true;
}
// Read-only snapshots: do not clear status or change radio mode.
static uint32_t rxDiagFollowupMs=0;
static void emitStartRxDiag(const char* phase){
  uint64_t captured=nowUs();bool armed=rxArmed;uint8_t state[5]{},status[5]{};
  regRead(0x19,0xFFFF,state,5);regRead(0x0F,0xFFFF,status,5);
  event("{\"event\":\"SESSION_START_RX_DIAG\",\"role\":\"tag\",\"session\":%lu,\"boot\":%lu,\"phase\":\"%s\",\"esp_us\":%llu,\"rxArmed\":%s,\"armed_us\":%llu,\"sys_state_hex_le\":\"%02x%02x%02x%02x%02x\",\"sys_status_hex_le\":\"%02x%02x%02x%02x%02x\",\"ctrl\":%u,\"ls\":%u}",
   (unsigned long)sessionId,(unsigned long)bootId,phase,(unsigned long long)captured,armed?"true":"false",(unsigned long long)armedAt,
   state[0],state[1],state[2],state[3],state[4],status[0],status[1],status[2],status[3],status[4],unsigned(digitalRead(CTRL)),unsigned(digitalRead(LS)));
}
static bool sendSessionStartBurst(uint32_t count){
  if(IS_ANCHOR)return false;
  bool ok=true;
  for(unsigned i=0;i<3;i++){
    ok=sendSessionStartPacket(count,i)&&ok;
    if(i<2)delay(20);
  }
  emitStartRxDiag("after_tx_before_arm");
  selectRoute(0);armRx();emitStartRxDiag("immediately_after_arm");rxDiagFollowupMs=millis()+100;return ok;
}

static bool sendDelayedStep(Result& r,uint8_t typ,uint64_t target,const uint64_t* rt=nullptr){
  if(r.ntx>=MAX_TX){fail(r,"TX_ARRAY_BOUNDS");return false;}TxObs& o=r.tx[r.ntx++];
  if(sendDelayedPacket(typ,r.txn,target,o,rt))return true;char why[40];snprintf(why,sizeof(why),"TX_FAIL_%s",typeName(typ));fail(r,why);return false;
}
static bool sendImmediatePollStep(Result& r){
  if(r.ntx>=MAX_TX){fail(r,"TX_ARRAY_BOUNDS");return false;}TxObs& o=r.tx[r.ntx++];
  if(sendImmediatePoll(r.txn,o))return true;fail(r,"TX_FAIL_POLL");return false;
}
static void storeRx(Result& r,RxObs& o){if(r.nrx<MAX_RX)r.rx[r.nrx++]=o;else fail(r,"RX_ARRAY_BOUNDS");}

static void runAnchor(uint32_t id){
  int slot=reserveResult(id);if(slot<0){event("{\"event\":\"RESOURCE_DROP\",\"role\":\"anchor\",\"session\":%lu,\"txn\":%lu}",(unsigned long)sessionId,(unsigned long)id);return;}
  Result& r=pool[slot];bool success=true;uint64_t burstBase=0;
  if(cfg.mode!=4){
    success=sendImmediatePollStep(r);
    if(success){
      AirPacket response{};RxObs obs{};uint64_t ta1=r.tx[0].actual;
      success=waitPacket(RESPONSE,id,(ta1+usTicks(cfg.reply_us))&MASK40,response,obs,r);
      if(success){
        if(cfg.diag_fast)diagnostics(obs);
        finishRx();storeRx(r,obs);
        r.fast[0]=ta1;r.fast[1]=response.ts[0];r.fast[2]=response.ts[1];r.fast[3]=obs.hw;r.ci_resp_raw=obs.ci_raw;
        double ciBias=double(cfg.ci_bias_ppb)/1000.0;
        r.fast_valid=ciRange(r.fast[0],r.fast[1],r.fast[2],r.fast[3],r.ci_resp_raw,ciBias,r.range_ci_inst,r.tof_ci_inst,r.ci_corr_ppm);
        r.ci_resp_ppm=double(r.ci_resp_raw)*CI_PPM_PER_RAW;
        if(r.fast_valid){
          r.ci3_corr_ppm=pushCiHistory(r.ci_corr_ppm,cfg.ci_smooth_n);r.ci_hist_count=ciHistCount;
          double q=r.ci3_corr_ppm*1e-6;double ra=double(delta40(r.fast[3],r.fast[0])),db=double(delta40(r.fast[2],r.fast[1]));
          r.tof_ci3=0.5*(ra-db*(1.0-q));r.range_ci3=r.tof_ci3*DTU_S*C_AIR_MPS;
        }else{success=false;fail(r,"INVALID_FAST_INTERVALS");}
        burstBase=(obs.hw+usTicks(cfg.burst_guard_us))&MASK40;
      }
    }
  }
  if(success&&cfg.mode!=3){
    uint64_t base=cfg.mode==4?((sysTime()+usTicks(6000))&MASK40):burstBase;
    for(unsigned i=0;i<3&&success;i++)success=sendDelayedStep(r,uint8_t(A1+i),(base+usTicks(uint64_t(i)*cfg.probe_gap_us))&MASK40);
  }
  r.ok=success&&!r.failure[0];submitResult(slot);idleRadio();
}

// R1L Tag side: take the Anchor block from the probes and complete the direct range locally.
static uint32_t gR1LTagPointBlocks=0,gR1LTagPointCrc=0xFFFFFFFFUL,gR1LTagBlocksTotal=0,gR1LTagBlockMismatch=0;
static void r1lTagPointReset(){gR1LTagPointBlocks=0;gR1LTagPointCrc=0xFFFFFFFFUL;}
static void r1lTagTakeBlock(Result& r,const AirPacket& p){
  if(p.blk_len!=R1L_BLOCK_BYTES)return;
  if(!r.ablk_present){memcpy(r.ablk,p.blk,R1L_BLOCK_BYTES);r.ablk_present=true;}
  else if(memcmp(r.ablk,p.blk,R1L_BLOCK_BYTES)!=0)r.ablk_mismatch=true;
  ++r.ablk_copies;
}
static void r1lTagApplyBlock(Result& r){
  if(!r.ablk_present)return;
  ++gR1LTagBlocksTotal;
  if(r.ablk_mismatch){++gR1LTagBlockMismatch;return;}
  gR1LTagPointCrc=crcUpdate(gR1LTagPointCrc,r.ablk,R1L_BLOCK_BYTES);++gR1LTagPointBlocks;
  AnchorBlock b{};if(!unpackAnchorBlock(r.ablk,b)||!(b.flags&2))return;
  if(r.conf.mode==4||!r.ntx||r.tx[0].type!=RESPONSE||!r.tx[0].ok)return;
  r.fast[0]=b.t_poll_tx;r.fast[3]=b.t_resp_rx;r.ci_resp_raw=b.ci_raw;r.ci_resp_ppm=double(b.ci_raw)*CI_PPM_PER_RAW;
  const double bias=double(r.conf.ci_bias_ppb)/1000.0;
  // Same expressions as runAnchor(): bit-identical to the Anchor's range_ci_inst / range_ci3.
  r.fast_valid=ciRange(r.fast[0],r.fast[1],r.fast[2],r.fast[3],r.ci_resp_raw,bias,r.range_ci_inst,r.tof_ci_inst,r.ci_corr_ppm);
  if(r.fast_valid){
    r.ci3_corr_ppm=r1lCi3Ppm(b,bias,r.conf.ci_smooth_n);r.ci_hist_count=b.ci_hist_count;
    double q=r.ci3_corr_ppm*1e-6;double ra=double(delta40(r.fast[3],r.fast[0])),db=double(delta40(r.fast[2],r.fast[1]));
    r.tof_ci3=0.5*(ra-db*(1.0-q));r.range_ci3=r.tof_ci3*DTU_S*C_AIR_MPS;r.ablk_used=true;
  }
}
static void runTag(AirPacket& first,RxObs& firstObs){
  int slot=reserveResult(first.h.txn);if(slot<0){finishRx();idleRadio();selectRoute(0);return;}
  Result& r=pool[slot];bool success=true;AirPacket p=first;RxObs o=firstObs;uint64_t burstExpected=0;r.rx_w4r=gTagW4R;
  double probeFp[3]={NAN,NAN,NAN};
  if(cfg.mode!=4){
    r.fast_route=effectiveFastRouteForTxn(cfg,r.txn);
    r.fast[1]=o.hw;if(cfg.diag_fast)diagnostics(o);finishRx();
    if(!o.port_match||!o.settled||o.ls!=0){success=false;fail(r,"FAST_PORT_OR_SETTLE_MISMATCH");}
    storeRx(r,o);
    selectRoute(r.fast_route);waitSwitch();
    uint64_t rt[1]={r.fast[1]};if(success)success=sendDelayedStep(r,RESPONSE,(r.fast[1]+usTicks(cfg.reply_us))&MASK40,rt);
    if(success){r.fast[2]=r.tx[0].actual;burstExpected=(r.fast[2]+usTicks(cfg.burst_guard_us))&MASK40;}
  }
  if(success&&cfg.mode!=3){
    const bool bab=isBabTxn(cfg,r.txn);
    const uint8_t probeTypes[3]={uint8_t(bab?B1:A1),uint8_t(bab?PROBE_A:B),uint8_t(bab?B2:A2)};
    const uint8_t probeRoutes[3]={uint8_t(bab?1:0),uint8_t(bab?0:1),uint8_t(bab?1:0)};
    for(unsigned i=0;i<3&&success;i++){
      if(!(cfg.mode==4&&i==0)){
        o=RxObs{};selectRoute(probeRoutes[i]);
        uint64_t expected=i==0?burstExpected:(r.aba_rx[0]+usTicks(uint64_t(i)*cfg.probe_gap_us))&MASK40;
        success=waitPacket(probeTypes[i],r.txn,expected,p,o,r);if(!success)break;
      }
      diagnostics(o);probeFp[i]=double(o.fp_raw)/64.0;r.aba_tx[i]=p.ts[0];r.aba_rx[i]=o.hw;r1lTagTakeBlock(r,p);captureCir(r,o,i);finishRx();
      if(!o.port_match||!o.settled||o.ls!=0)fail(r,"PORT_OR_SETTLE_MISMATCH");storeRx(r,o);
      if(i<2){selectRoute(probeRoutes[i+1]);armRx();}
    }
    if(success){r.aba_valid=abaDelta(r.aba_tx,r.aba_rx,r.aba_clock_ppm,r.delta_ba);if(!r.aba_valid){success=false;fail(r,"INVALID_ABA_INTERVALS");}}
    if(success){
      // R1J: no physical-value gate. Preserve fp_index spread as a raw diagnostic only;
      // user-defined physical gating is applied later and must not change RESULT.ok.
      double lo=probeFp[0],hi=probeFp[0];for(unsigned k=1;k<3;k++){if(probeFp[k]<lo)lo=probeFp[k];if(probeFp[k]>hi)hi=probeFp[k];}
      r.fp_spread_samples=hi-lo;
    }
  }
  r1lTagApplyBlock(r);
  r.ok=success&&!r.failure[0]&&!tagRxFault;
  if(!tagRxFault)DW1000Ng::setWait4Response(0);
  idleRadio();selectRoute(0);submitResult(slot);
}

static double pwrDb(const RxObs& o,bool fp,bool correction){
  if(!o.diag||!o.nacc)return NAN;
  double e=fp?(double(o.f1)*o.f1+double(o.f2)*o.f2+double(o.f3)*o.f3):(double(o.cir_pwr)*131072.0);
  if(e<=0)return NAN;double p=10*log10(e/(double(o.nacc)*o.nacc))-113.77;
  if(correction&&p>-88)p+=(p+88)*2.3334;return p;
}
static void resultJson(Result& r,Json& j){
  j.add("{\"event\":\"RESULT\",\"role\":\"%s\",\"firmware\":\"RF_PLATFORM_V1\",\"boot\":%lu,\"peer_boot\":%lu,\"session\":%lu,\"txn\":%lu,\"config_id\":%lu,\"config\":",role(),(unsigned long)r.boot,(unsigned long)r.peer,(unsigned long)r.session,(unsigned long)r.txn,(unsigned long)configId(r.conf));appendConfig(j,r.conf);
  {const bool bab=isBabTxn(r.conf,r.txn);const char* fast=(r.conf.mode==4)?"NONE":antRouteName(r.fast_route);const char* leg=(r.conf.mode==4)?"NONE":fast;
    j.add(",\"profile\":\"RAWCAL_PAIR_R04_ABDIRECT\",\"response_tx_route\":\"%s\",\"fast_route\":\"%s\",\"pair_leg\":\"%s\",\"ant_tx_requested\":%u,\"ant_rx_requested\":%u,\"ant_tx_readback\":%u,\"ant_rx_readback\":%u,\"ant_readback_ok\":%s",fast,fast,leg,r.ant_tx_requested,r.ant_rx_requested,r.ant_tx_readback,r.ant_rx_readback,r.ant_readback_ok?"true":"false");
    j.add(",\"ok\":%s,\"failure\":\"%s\",\"begin_us\":%llu,\"end_us\":%llu,\"rf_work_us\":%llu,\"fast_valid\":%s,\"aba_valid\":%s,\"probe_valid\":%s,\"probe_sequence\":\"%s\",\"logical_sample_id\":%lu,\"cir_mask\":%u,",r.ok?"true":"false",r.failure,(unsigned long long)r.begin_us,(unsigned long long)r.end_us,(unsigned long long)(r.end_us-r.begin_us),r.fast_valid?"true":"false",r.aba_valid?"true":"false",r.aba_valid?"true":"false",bab?"BAB":"ABA",(unsigned long)logicalSampleId(r.conf,r.txn),r.cir_mask);}
  j.num("range_ci_inst_m",r.range_ci_inst);j.num("range_ci3_m",r.range_ci3);j.num("tof_ci_inst_dtu",r.tof_ci_inst);j.num("tof_ci3_dtu",r.tof_ci3);
  j.num("ci_resp_ppm",r.ci_resp_ppm);j.num("ci_corrected_ppm",r.ci_corr_ppm);j.num("ci3_corrected_ppm",r.ci3_corr_ppm);
  j.add("\"ci_resp_raw\":%ld,\"ci_hist_count\":%u,",(long)r.ci_resp_raw,r.ci_hist_count);
  {AnchorBlock b{};const bool okb=r.ablk_present&&unpackAnchorBlock(r.ablk,b);
    j.add("\"direct_range_source\":%s,\"anchor_block\":",r.ablk_used?"\"probe_block\"":"null");
    if(!okb){j.add("null,");j.num("anchor_rx_dbm",NAN);j.num("anchor_fp_dbm",NAN);}
    else{
      RxObs a{};a.diag=true;a.nacc=b.rxpacc;a.cir_pwr=b.cir_pwr;a.f1=b.f1;a.f2=b.f2;a.f3=b.f3;
      j.add("{\"version\":%u,\"copies\":%u,\"consistent\":%s,\"used\":%s,\"anchor_store\":%u,\"fast_valid\":%s,\"prev_txn_status\":%u,\"resp_ok_bitmap\":%u,\"ci_hist_count\":%u,\"valid_count\":%u,",
        unsigned(R1L_BLOCK_VERSION),unsigned(r.ablk_copies),r.ablk_mismatch?"false":"true",r.ablk_used?"true":"false",unsigned(b.flags&1),(b.flags&2)?"true":"false",unsigned(b.prev_status),unsigned(b.resp_ok_bitmap),unsigned(b.ci_hist_count),unsigned(b.valid_count));
      j.add("\"t_poll_tx\":%llu,\"t_resp_rx\":%llu,\"ci_raw\":%ld,\"ci_raw_prev1\":%ld,\"ci_raw_prev2\":%ld,\"fp_raw\":%u,\"fp_index\":%.6f,\"rxpacc\":%u,\"cir_pwr\":%u,\"f1\":%u,\"f2\":%u,\"f3\":%u,\"std_noise\":%u,\"sys_status\":%lu,",
        (unsigned long long)b.t_poll_tx,(unsigned long long)b.t_resp_rx,(long)b.ci_raw,(long)b.ci_prev1,(long)b.ci_prev2,unsigned(b.fp_raw),double(b.fp_raw)/64,unsigned(b.rxpacc),unsigned(b.cir_pwr),unsigned(b.f1),unsigned(b.f2),unsigned(b.f3),unsigned(b.std_noise),(unsigned long)b.sys_status);
      j.num("rx_dbm",pwrDb(a,false,true));j.num("fp_dbm",pwrDb(a,true,true));j.num("rx_dbm_uncorrected",pwrDb(a,false,false));j.num("fp_dbm_uncorrected",pwrDb(a,true,false),false);j.add("},");
      j.num("anchor_rx_dbm",pwrDb(a,false,true));j.num("anchor_fp_dbm",pwrDb(a,true,true));
    }
  }
  j.num("fp_spread_samples",r.fp_spread_samples);j.add("\"fp_outlier\":null,\"physical_gates_enabled\":false,\"rx_w4r\":%s,\"diag_rev\":\"R1J\",",r.rx_w4r?"true":"false");
  {const bool bab=isBabTxn(r.conf,r.txn);const double deltaBMinusA=r.aba_valid?(bab?-r.delta_ba:r.delta_ba):NAN;
    j.num("aba_clock_ppm",r.aba_clock_ppm);j.num("probe_delta_raw_m",r.delta_ba);j.num("delta_b_minus_a_m",deltaBMinusA);j.num("delta_ba_m",deltaBMinusA);j.num("probe_clock_ppm",r.aba_clock_ppm);j.num("probe_delta_m",r.delta_ba);
    j.num("range_direct_m",r.range_ci_inst);j.num("range_direct_ci3_m",r.range_ci3);
    j.num("range_a_direct_m",r.fast_route==ROUTE_A?r.range_ci_inst:NAN);j.num("range_a_direct_ci3_m",r.fast_route==ROUTE_A?r.range_ci3:NAN);
    j.num("range_b_direct_m",r.fast_route==ROUTE_B?r.range_ci_inst:NAN);j.num("range_b_direct_ci3_m",r.fast_route==ROUTE_B?r.range_ci3:NAN);
    if(r.fast_valid&&r.aba_valid&&r.fast_route==ROUTE_A){r.range_b_inst=r.range_ci_inst+deltaBMinusA;r.range_b_ci3=r.range_ci3+deltaBMinusA;}
  }
  j.num("range_b_inst_m",r.range_b_inst);j.num("range_b_ci3_m",r.range_b_ci3);
  j.add("\"fast_timestamps\":[");for(unsigned i=0;i<4;i++)j.add("%s%llu",i?",":"",(unsigned long long)r.fast[i]);j.add("],\"aba_tx\":[");
  for(unsigned i=0;i<3;i++)j.add("%s%llu",i?",":"",(unsigned long long)r.aba_tx[i]);j.add("],\"aba_rx\":[");
  for(unsigned i=0;i<3;i++)j.add("%s%llu",i?",":"",(unsigned long long)r.aba_rx[i]);j.add("],\"tx\":[");
  for(unsigned i=0;i<r.ntx;i++){auto& t=r.tx[i];j.add("%s{\"ctrl\":%u,\"ls\":%u,",i?",":"",t.ctrl,t.ls);j.add("\"type\":\"%s\",\"bytes\":%u,\"ok\":%s,\"planned\":%llu,\"actual\":%llu,\"delta_ticks\":%ld,\"lead_start_us\":%ld,\"lead_arm_us\":%ld,\"prepare_us\":%lu,\"wait_us\":%lu,\"begin_us\":%llu,\"done_us\":%llu,\"sys_status\":%llu}",typeName(t.type),t.bytes,t.ok?"true":"false",(unsigned long long)t.planned,(unsigned long long)t.actual,(long)t.tx_delta_ticks,(long)t.lead_start_us,(long)t.lead_arm_us,(unsigned long)t.prepare_us,(unsigned long)t.wait_us,(unsigned long long)t.begin_us,(unsigned long long)t.done_us,(unsigned long long)t.status);}
  j.add("],\"rx\":[");
  for(unsigned i=0;i<r.nrx;i++){auto& o=r.rx[i];j.add("%s{\"type\":\"%s\",\"bytes\":%u,\"rx_hw\":%llu,\"rx_raw_hw\":%llu,\"lde_adjust_ticks\":%lld,\"lde_done\":%s,\"tx_planned\":%llu,\"source_boot\":%lu,\"esp_us\":%llu,\"armed_us\":%llu,\"switch_us\":%llu,\"arm_lead_us\":%ld,\"preamble_margin_us\":%ld,\"ctrl\":%u,\"ls\":%u,\"settled\":%s,\"port_match\":%s,\"fetch_us\":%lu,\"diag_us\":%lu,\"cir_us\":%lu,\"compare_us\":%lu,\"verify_us\":%lu,\"verify_bad\":%ld,\"verify_repeat_bad\":%ld,\"cir_slot\":%d,\"diag\":%s,",i?",":"",typeName(o.type),o.bytes,(unsigned long long)o.hw,(unsigned long long)o.raw_hw,(long long)o.lde_adjust_ticks,o.lde_done?"true":"false",(unsigned long long)o.tx_planned,(unsigned long)o.source_boot,(unsigned long long)o.esp_us,(unsigned long long)o.arm_us,(unsigned long long)o.switch_us,(long)o.arm_lead_us,(long)o.preamble_margin_us,o.ctrl,o.ls,o.settled?"true":"false",o.port_match?"true":"false",(unsigned long)o.fetch_us,(unsigned long)o.diag_us,(unsigned long)o.cir_us,(unsigned long)o.compare_us,(unsigned long)o.verify_us,(long)o.verify_bad,(long)o.verify_repeat_bad,int(o.cir_slot),o.diag?"true":"false");
    j.add("\"received\":%s,",o.received?"true":"false");
    j.add("\"first_arm_lead_us\":%ld,\"rearm_count\":%u,\"wait_rx_errors\":%u,\"wait_rejects\":%u,\"wait_unexpected\":%u,\"last_reject_code\":%u,\"last_reject_status\":%llu,\"last_reject_vs_expected_us\":%ld,\"arm_source\":\"%s\",",
      (long)o.first_arm_lead_us,unsigned(o.rearm_count),unsigned(o.wait_rx_errors),unsigned(o.wait_rejects),unsigned(o.wait_unexpected),unsigned(o.last_reject_code),(unsigned long long)o.last_reject_status,(long)o.last_reject_vs_expected_us,o.arm_source?"W4R":"SW");
    j.add("\"detect_lag_us\":%ld,\"observed_arm_to_rmarker_us\":%ld,",(long)o.detect_lag_us,(long)o.observed_arm_to_rmarker_us);
    j.num("rx_dbm",pwrDb(o,false,true));j.num("fp_dbm",pwrDb(o,true,true));j.num("rx_dbm_uncorrected",pwrDb(o,false,false));j.num("fp_dbm_uncorrected",pwrDb(o,true,false));
    j.add("\"fp_raw\":%u,\"fp_index\":%.6f,\"rxpacc\":%u,\"cir_pwr\":%u,\"f1\":%u,\"f2\":%u,\"f3\":%u,\"std_noise\":%u,\"ci_raw\":%ld,\"ci_ppm\":%.9f,\"ttcki\":%lu,\"ttcko\":%llu,\"sys_status\":%llu,\"air_hex\":\"",o.fp_raw,double(o.fp_raw)/64,o.nacc,o.cir_pwr,o.f1,o.f2,o.f3,o.noise,(long)o.ci_raw,double(o.ci_raw)*CI_PPM_PER_RAW,(unsigned long)o.ttcki,(unsigned long long)o.ttcko,(unsigned long long)o.status);
    for(unsigned k=0;k<o.bytes;k++)j.add("%02x",o.raw_air[k]);j.add("\"");
    if(o.cir_slot>=0){auto raw=r.cir[unsigned(o.cir_slot)];uint64_t energy=0;unsigned nonzero=0,saturated=0;
      for(unsigned k=0;k<NSAMP;k++){int32_t re=int16_t(le16(raw+4*k)),im=int16_t(le16(raw+4*k+2));energy+=uint64_t(int64_t(re)*re+int64_t(im)*im);if(re||im)++nonzero;if(re==-32768||re==32767||im==-32768||im==32767)++saturated;}
      j.add(",\"cir_crc\":%lu,\"cir_samples\":%u,\"wire_cir_offset\":%u,\"cir_energy\":%llu,\"cir_nonzero_samples\":%u,\"cir_saturated_samples\":%u",(unsigned long)crc32(raw,CIR_BYTES),NSAMP,unsigned(o.cir_slot)*CIR_BYTES,(unsigned long long)energy,nonzero,saturated);
    }
    j.add("}");
  }
  j.add("],\"wire_cir_layout\":\"%s;missing_slots_zero_filled_do_not_use\"}",isBabTxn(r.conf,r.txn)?"B1,A,B2":"A1,B,A2");
}
static void writeWire(uint8_t kind,const char* json,size_t n,const uint8_t* raw,size_t rawN){
  static uint32_t seq=0;WireHeader h{WIRE_MAGIC,1,kind,sizeof(WireHeader),seq++,uint32_t(n),uint32_t(rawN),0};
  uint32_t c=crcUpdate(0xFFFFFFFFUL,&h,offsetof(WireHeader,crc));c=crcUpdate(c,json,n);if(rawN)c=crcUpdate(c,raw,rawN);h.crc=c^0xFFFFFFFFUL;
  Serial.write((const uint8_t*)&h,sizeof(h));Serial.write((const uint8_t*)json,n);if(rawN)Serial.write(raw,rawN);++sentRecords;
}
static void writerTask(void*){
  static char json[10240];OutMsg m;
  for(;;){if(xQueueReceive(outQ,&m,portMAX_DELAY)!=pdTRUE)continue;writerBusy=true;
    if(m.kind==2){Result& r=pool[m.index];Json j(json,sizeof(json));resultJson(r,j);
      if(j.ok){size_t n=(!IS_ANCHOR&&r.conf.mode!=3)?3*CIR_BYTES:0;writeWire(2,json,j.n,n?r.cir[0]:nullptr,n);}
      else {const char* e="{\"event\":\"JSON_OVERFLOW\"}";writeWire(1,e,strlen(e),nullptr,0);++outputDrops;}
      uint8_t i=m.index;xQueueSend(freeQ,&i,portMAX_DELAY);
    }else {writeWire(1,m.text,strlen(m.text),nullptr,0);
      if(m.kind==3){Serial.flush();vTaskDelay(pdMS_TO_TICKS(250));Serial.updateBaudRate(m.baud);currentBaud=m.baud;}
    }
    --outputPending;writerBusy=false;
  }
}

static bool parseU32(char*& cur,uint32_t& v){while(*cur&&isspace((unsigned char)*cur))++cur;if(!isdigit((unsigned char)*cur))return false;char* end;unsigned long long x=strtoull(cur,&end,10);if(end==cur||x>0xFFFFFFFFULL)return false;v=uint32_t(x);cur=end;return true;}
#include "platform_ext.hpp"
static void ack(uint32_t req,bool ok,const char* op,const char* why="OK"){
  event("{\"event\":\"ACK\",\"request\":%lu,\"role\":\"%s\",\"op\":\"%s\",\"ok\":%s,\"reason\":\"%s\",\"boot\":%lu,\"session\":%lu,\"config_id\":%lu}",(unsigned long)req,role(),op,ok?"true":"false",why,(unsigned long)bootId,(unsigned long)sessionId,(unsigned long)configId(cfg));
}
#include "uwb_wifi_provision.hpp"
#include "route_v1.hpp"
#include "rx_probe.hpp"
static void command(char* line){
  char* cur=line;char op[16];size_t n=0;while(*cur&&!isspace((unsigned char)*cur)){if(n<15)op[n++]=*cur;cur++;}op[n]=0;
  uint32_t req;if(!parseU32(cur,req))return;
  if(!strcmp(op,"RESETINFO")){event("{\"event\":\"ACK\",\"request\":%lu,\"op\":\"RESETINFO\",\"ok\":true,\"boot\":%lu,\"reset_reason\":%u}",(unsigned long)req,(unsigned long)bootId,unsigned(esp_reset_reason()));return;}
  if(!strcmp(op,"RXSTATE")){
    while(*cur&&isspace((unsigned char)*cur))++cur;
    if(*cur||IS_ANCHOR||tagRxFault||!hwOK){ack(req,false,op,"HEALTHY_TAG_NO_ARGS_REQUIRED");return;}
    SPIporting::RxSpeedScope rxSpeed(true);
    const uint64_t began=nowUs();uint8_t state[5]{},status[5]{};
    regRead(0x19,0xFFFF,state,5);const uint64_t stateEnd=nowUs();
    regRead(0x0F,0xFFFF,status,5);const uint64_t ended=nowUs();
    const uint64_t ss=le40(status);const bool bad=!tagdiag::statusTrusted(ss)||le40(state)==0xFFFFFFFFFFULL;
    const uint32_t clock=SPI.getClockDivider(),ctrl=SPIporting::lastTransactionCtrl2();
    if(bad)tagGuardTrip(1,ss,71);
    event("{\"event\":\"ACK\",\"request\":%lu,\"op\":\"RXSTATE\",\"ok\":%s,\"boot\":%lu,\"session\":%lu,\"begin_us\":%llu,\"state_end_us\":%llu,\"end_us\":%llu,\"active\":%s,\"rx_armed\":%s,\"ctrl\":%u,\"ls\":%u,\"clock\":%lu,\"spi_ctrl2\":%lu,\"state_hex_le\":\"%02x%02x%02x%02x%02x\",\"status_hex_le\":\"%02x%02x%02x%02x%02x\"}",
      (unsigned long)req,bad?"false":"true",(unsigned long)bootId,(unsigned long)sessionId,(unsigned long long)began,(unsigned long long)stateEnd,(unsigned long long)ended,active?"true":"false",rxArmed?"true":"false",unsigned(digitalRead(CTRL)),unsigned(digitalRead(LS)),(unsigned long)clock,(unsigned long)ctrl,
      state[0],state[1],state[2],state[3],state[4],status[0],status[1],status[2],status[3],status[4]);return;
  }
  if(!strcmp(op,"ARMENABLE")){
    uint32_t enabled=2;
    if(active||rxArmed||tagRxFault||!hwOK||!parseU32(cur,enabled)||enabled>1){ack(req,false,op,"IDLE_UNLATCHED_BOOL_REQUIRED");return;}
    while(*cur&&isspace((unsigned char)*cur))++cur;if(*cur){ack(req,false,op,"ONE_ARG");return;}
    armRxEnableBit=enabled!=0;ack(req,true,op);return;
  }
  if(!strcmp(op,"ARMTUNE")){
    uint32_t gap=0,settle=0;
    if(active||rxArmed||tagRxFault||!hwOK||!parseU32(cur,gap)||!parseU32(cur,settle)||gap>1000||settle>5000){ack(req,false,op,"IDLE_GAP_0_1000_SETTLE_0_5000");return;}
    while(*cur&&isspace((unsigned char)*cur))++cur;if(*cur){ack(req,false,op,"TWO_ARGS");return;}
    searchGapUs=gap;searchSettleUs=settle;
    SPIporting::setProbeTiming(2000000,2,searchGapUs);ack(req,true,op);return;
  }
  if(!strcmp(op,"ARMCHECK")){
    if(tagRxFault||!active||!rxArmed){ack(req,false,op,"ACTIVE_HEALTHY_RX_REQUIRED");return;}
    const bool good=tagGuardCheck(70,0);ack(req,good,op,good?"OK":"TAG_RX_GUARD_LATCHED");return;
  }
  if(!strcmp(op,"DWRESETONCE")){
    while(*cur&&isspace((unsigned char)*cur))++cur;
    if(*cur||active||rxArmed||tagRxFault||remaining||r03TagPointActive||r03TagAwaitCommit){ack(req,false,op,"IDLE_UNLATCHED_NO_ARGS_REQUIRED");return;}
    static uint32_t attempts=0;const uint32_t before=attempts;const uint64_t started=nowUs();
    hwOK=false;SPIporting::setProbeTiming(0,0,0);searchGapUs=0;searchSettleUs=0;
    ++attempts;DW1000Ng::initializeNoInterrupt(CS,RST); // exactly one full initialization, RST17 LOW then INPUT
    SPIporting::setSPIspeed(SPIClock::FAST);
    const bool initHealthy=healthy();
    if(initHealthy)hwOK=applyRadio(); // same startup configuration; no retry
    event("{\"event\":\"ACK\",\"request\":%lu,\"op\":\"DWRESETONCE\",\"ok\":%s,\"boot\":%lu,\"rst_gpio\":%u,\"attempts\":1,\"init_before\":%lu,\"init_after\":%lu,\"start_us\":%llu,\"end_us\":%llu,\"init_healthy\":%s,\"hw_ok\":%s,\"ant_readback_ok\":%s}",(unsigned long)req,hwOK?"true":"false",(unsigned long)bootId,unsigned(RST),(unsigned long)before,(unsigned long)attempts,(unsigned long long)started,(unsigned long long)nowUs(),initHealthy?"true":"false",hwOK?"true":"false",antReadbackOK?"true":"false");return;
  }
  if(rxProbeCommand(req,op,cur))return;
  if(tagDiagCommand(req,op,cur))return;
  if(strcmp(op,"SPIKEEPINFO")==0){
    event(R"json({"event":"ACK","request":%lu,"op":"SPIKEEPINFO","ok":true,"boot":%lu,"rx_armed":%s,"rx_transactions":%lu,"rx_violations":%lu,"last_rx_clock":%lu,"last_rx_ctrl2":%lu})json",
      (unsigned long)req,(unsigned long)bootId,rxArmed?"true":"false",(unsigned long)SPIporting::rxTransactionCount(),(unsigned long)SPIporting::rxViolationCount(),(unsigned long)SPIporting::rxLastClock(),(unsigned long)SPIporting::rxLastCtrl2());return;
  }

  if(strcmp(op,"RXGUARDINFO")==0){
    event("{\"event\":\"ACK\",\"request\":%lu,\"op\":\"RXGUARDINFO\",\"ok\":true,\"role\":\"tag\",\"candidate\":\"R1K8_R1L80\",\"boot\":%lu,\"session\":%lu,\"latched\":%s,\"reason\":%u,\"stage\":%u,\"t_us\":%llu,\"status\":%llu,\"shutdown_attempted\":%s,\"dev\":%lu,\"tx\":%u,\"rx\":%u,\"time_a\":%llu,\"time_b\":%llu,\"validated_resets\":%lu}",
      (unsigned long)req,(unsigned long)bootId,(unsigned long)sessionId,tagRxFault?"true":"false",unsigned(tagFaultReason),unsigned(tagFaultStage),(unsigned long long)tagFaultUs,(unsigned long long)tagFaultStatus,tagShutdownAttempted?"true":"false",(unsigned long)tagCheckDev,unsigned(tagCheckTx),unsigned(tagCheckRx),(unsigned long long)tagCheckTimeA,(unsigned long long)tagCheckTimeB,(unsigned long)tagValidatedResets);return;
  }
  if(tagRxFault && strcmp(op,"STOP") && strcmp(op,"HELLO") && strcmp(op,"STATUS") && strcmp(op,"SPIAUDIT") && strcmp(op,"SELFTEST") && strcmp(op,"ROUTESTATUS") && strcmp(op,"GETCONFIG") && strcmp(op,"E6INFO") && strcmp(op,"E6FAULT") && strcmp(op,"E6EVENT") && strcmp(op,"E5INFO") && strcmp(op,"E5TRACE") && strcmp(op,"E5WRITE") && strcmp(op,"REBOOT")){
    ack(req,false,op,"TAG_RX_GUARD_LATCHED_REBOOT_REQUIRED");return;
  }
  if(platformCommand(req,op,cur))return;

  // R1J6_SPIAUDIT_E1E4_V1: Tag-only diagnostic, not an RF experiment trigger.
  // Must not be used while any Route point is being measured/committed.
  if(strcmp(op,"SPIAUDIT")==0){
    uint32_t mhz=0;
    if(!parseU32(cur,mhz)||(mhz!=8&&mhz!=10&&mhz!=20)){
      ack(req,false,op,"MHZ_8_10_OR_20_REQUIRED");return;
    }
    while(*cur&&isspace((unsigned char)*cur))cur++;
    if(*cur){ack(req,false,op,"EXTRA_ARGUMENT");return;}
    if(active||rxArmed||r03TagPointActive||r03TagAwaitCommit||remaining){
      ack(req,false,op,"POINT_OR_RF_IN_PROGRESS");return;
    }
    // SPIAUDIT does not write DW1000 registers. Only the selected diagnostic
    // read transactions use the requested speed. RX must remain off.
    SPIporting::RxSpeedScope auditRx8(mhz==8);
    SPIporting::setSPIspeed(SPIClock::FAST);
    SPIporting::setDiagnosticFast10(mhz==10);
    uint8_t dev[4]{},st[5]{},tx[2]{},rx[2]{},stat[5]{};
    regRead(0x00,0xFFFF,dev,4);            // DEV_ID
    regRead(0x06,0xFFFF,st,5);             // SYS_TIME
    regRead(0x18,0xFFFF,tx,2);            // TX_ANTD
    regRead(0x2E,0x1804,rx,2);           // LDE_RXANTD
    regRead(0x0F,0xFFFF,stat,5);          // SYS_STATUS
    const uint32_t clockDiv=SPI.getClockDivider();
    const uint32_t modeRead=spiGetDataMode(SPI.bus());
    const uint32_t bitRead=spiGetBitOrder(SPI.bus());
    event("{\"event\":\"SPISETTINGS\",\"request\":%lu,\"boot\":%lu,\"mhz\":%lu,\"clock_div_raw\":%lu,\"mode_readback\":%lu,\"msb_first_readback\":%lu,\"apb_hz\":%lu,\"transaction_ctrl2\":%lu,\"idle_ctrl2\":%lu}",
      (unsigned long)req,(unsigned long)bootId,(unsigned long)mhz,(unsigned long)clockDiv,(unsigned long)modeRead,(unsigned long)bitRead,(unsigned long)getApbFrequency(),(unsigned long)SPIporting::lastTransactionCtrl2(),(unsigned long)REG_READ(SPI_CTRL2_REG(3)));
    SPIporting::setDiagnosticFast10(false); // scope restores RX2 selection on return
    e6AuditCapture(mhz,dev,st,tx,rx,stat,1);
    char dh[9]{},sh[11]{},th[5]{},rh[5]{},qh[11]{};
    for(unsigned i=0;i<4;i++)snprintf(dh+2*i,3,"%02x",unsigned(dev[i]));
    for(unsigned i=0;i<5;i++)snprintf(sh+2*i,3,"%02x",unsigned(st[i]));
    for(unsigned i=0;i<2;i++)snprintf(th+2*i,3,"%02x",unsigned(tx[i]));
    for(unsigned i=0;i<2;i++)snprintf(rh+2*i,3,"%02x",unsigned(rx[i]));
    for(unsigned i=0;i<5;i++)snprintf(qh+2*i,3,"%02x",unsigned(stat[i]));
    event("{\"event\":\"ACK\",\"request\":%lu,\"op\":\"SPIAUDIT\",\"ok\":true,"
          "\"role\":\"tag\",\"diag_rev\":\"R1J6_SPIAUDIT_E1E4_V1\","
          "\"boot\":%lu,\"session\":%lu,\"active\":%s,\"rx_armed\":%s,"
          "\"mhz\":%lu,\"dev_id\":%lu,\"sys_time\":%llu,"
          "\"tx_antd\":%u,\"rx_antd\":%u,\"sys_status\":%llu,"
          "\"dev_hex\":\"%s\",\"sys_hex\":\"%s\","
          "\"tx_hex\":\"%s\",\"rx_hex\":\"%s\",\"status_hex\":\"%s\"}",
          (unsigned long)req,(unsigned long)bootId,(unsigned long)sessionId,
          active?"true":"false",rxArmed?"true":"false",
          (unsigned long)mhz,(unsigned long)le32(dev),
          (unsigned long long)le40(st),unsigned(le16(tx)),unsigned(le16(rx)),
          (unsigned long long)le40(stat),dh,sh,th,rh,qh);
    return;
  }

  // R1J6_E5_ARM_TRACE_V1 -- all E5 data is volatile, no DW1000 writes here.
  // R1J6_E6_ROOT_CAUSE_V1: Tag-only RAM instrumentation, no RF TX/flash/reset.
  if(strcmp(op,"E6SET")==0){
    uint32_t profile=0;
    if(active||r03TagPointActive||r03TagAwaitCommit){ack(req,false,op,"IDLE_REQUIRED");return;}
    if(!parseU32(cur,profile)||profile<1||profile>4){ack(req,false,op,"PROFILE_1_TO_4");return;}
    while(*cur&&isspace((unsigned char)*cur))cur++;
    if(*cur){ack(req,false,op,"EXTRA_ARGUMENT");return;}
    // Disable E5 intrusive stages. E6 uses its existing SPIporting hook only.
    e5Level=0;e5InArm=false;e5Window=false;
    e6Reset(uint8_t(profile));
    SPIporting::setE5WriteObserver(e5ObserveWrite);
    event("{\"event\":\"ACK\",\"request\":%lu,\"op\":\"E6SET\",\"ok\":true,"
          "\"role\":\"tag\",\"boot\":%lu,\"profile\":%u,\"diag_rev\":\"R1J6_E6_ROOT_CAUSE_V1\"}",
          (unsigned long)req,(unsigned long)bootId,unsigned(e6Profile));return;
  }
  if(strcmp(op,"E6INFO")==0){
    event("{\"event\":\"ACK\",\"request\":%lu,\"op\":\"E6INFO\",\"ok\":true,"
          "\"role\":\"tag\",\"diag_rev\":\"R1J6_E6_ROOT_CAUSE_V1\","
          "\"boot\":%lu,\"session\":%lu,\"trace_session\":%lu,"
          "\"active\":%s,\"rx_armed\":%s,\"profile\":%u,\"armed_once\":%s,"
          "\"first_bad\":%s,\"first_bad_mask\":%lu,"
          "\"polls\":%lu,\"rearms\":%lu,\"rx_done\":%lu,\"rx_failed\":%lu,\"rx_timeout\":%lu,"
          "\"bad_air\":%lu,\"unexpected\":%lu,"
          "\"stale_2s\":%lu,\"hold_loops\":%lu,\"writes\":%lu,"
          "\"sysctrl\":%lu,\"trxoff\":%lu,\"rxenab\":%lu,"
          "\"rxsoft_low\":%lu,\"rxsoft_high\":%lu,\"rxsoft_pairs\":%lu,"
          "\"tx_antd_writes\":%lu,\"lde_writes\":%lu,"
          "\"good_samples\":%lu,\"bad_samples\":%lu,"
          "\"ring_n\":%u,\"ring_overwrites\":%lu,\"post_n\":%u,\"post_drops\":%lu}",
          (unsigned long)req,(unsigned long)bootId,(unsigned long)sessionId,(unsigned long)e6Session,
          active?"true":"false",rxArmed?"true":"false",unsigned(e6Profile),
          e6ArmedOnce?"true":"false",e6FirstBad?"true":"false",(unsigned long)e6FirstMask,
          (unsigned long)e6Polls,(unsigned long)e6Rearms,(unsigned long)e6Done,
          (unsigned long)e6Failed,(unsigned long)e6Timeout,(unsigned long)e6BadAir,
          (unsigned long)e6Unexpected,(unsigned long)e6Stale2s,
          (unsigned long)e6HoldLoops,(unsigned long)e6TotalWrites,
          (unsigned long)e6Sysctrl,(unsigned long)e6Trxoff,(unsigned long)e6Rxenab,
          (unsigned long)e6SoftLow,(unsigned long)e6SoftHigh,(unsigned long)e6SoftPairs,
          (unsigned long)e6TxWrites,(unsigned long)e6LdeWrites,
          (unsigned long)e6GoodSamples,(unsigned long)e6BadSamples,
          unsigned(e6RingN),(unsigned long)e6RingOverwrites,unsigned(e6PostN),
          (unsigned long)e6PostDrops);return;
  }
  if(strcmp(op,"E6FAULT")==0){
    event("{\"event\":\"ACK\",\"request\":%lu,\"op\":\"E6FAULT\",\"ok\":true,"
          "\"role\":\"tag\",\"boot\":%lu,\"exists\":%s,\"t_us\":%llu,\"mask\":%lu,"
          "\"first_active\":%u,\"first_rx_armed\":%u,\"first_source\":%u,"
          "\"dev_id\":%lu,\"sys_time\":%llu,\"tx_antd\":%u,\"rx_antd\":%u,"
          "\"polls\":%lu,\"rearms\":%lu,\"rxsoft_pairs\":%lu,\"tx_antd_writes\":%lu,"
          "\"rx_failed\":%lu,\"rx_timeout\":%lu,"
          "\"last_rxsoft_us\":%llu,\"last_rearm_us\":%llu,\"last_txwrite_us\":%llu,"
          "\"sys_status\":%llu,\"last_rx_status_lo\":%lu}",
          (unsigned long)req,(unsigned long)bootId,e6FirstBad?"true":"false",
          (unsigned long long)e6FirstUs,(unsigned long)e6FirstMask,
          unsigned(e6FirstActive),unsigned(e6FirstRxArmed),unsigned(e6FirstSource),
          (unsigned long)e6FirstDev,(unsigned long long)e6FirstSys,
          unsigned(e6FirstTx),unsigned(e6FirstRx),
          (unsigned long)e6FirstPolls,(unsigned long)e6FirstRearms,
          (unsigned long)e6FirstSoftPairs,(unsigned long)e6FirstTxWrites,
          (unsigned long)e6FirstFailed,(unsigned long)e6FirstTimeout,
          (unsigned long long)e6FirstLastSoftUs,(unsigned long long)e6FirstLastRearmUs,
          (unsigned long long)e6FirstLastTxWriteUs,(unsigned long long)e6FirstLastStatus,
          (unsigned long)e6LastRxStatusLo);return;
  }
  if(strcmp(op,"E6EVENT")==0){
    uint32_t i=0;if(!parseU32(cur,i)||i>=uint32_t(e6RingN)+uint32_t(e6PostN)){
      ack(req,false,op,"INDEX_OUT_OF_RANGE");return;
    }
    const bool post=(i>=e6RingN);
    const E6Event &e=post?e6Post[i-e6RingN]:e6Ring[(e6RingHead+i)%E6_RING_CAP];
    event("{\"event\":\"ACK\",\"request\":%lu,\"op\":\"E6EVENT\",\"ok\":true,"
          "\"role\":\"tag\",\"idx\":%lu,\"phase\":%u,\"code\":%u,"
          "\"t_us\":%llu,\"a\":%lu,\"b\":%lu,\"active\":%u,\"rx_armed\":%u}",
          (unsigned long)req,(unsigned long)i,unsigned(post?1:0),unsigned(e.code),
          (unsigned long long)e.us,(unsigned long)e.a,(unsigned long)e.b,
          unsigned(e.arm_active),unsigned(e.rx_armed));return;
  }
  if(strcmp(op,"E5SET")==0){
    uint32_t level=0;
    if(active||r03TagPointActive||r03TagAwaitCommit){ack(req,false,op,"IDLE_REQUIRED");return;}
    if(!parseU32(cur,level)||level<1||level>2){ack(req,false,op,"LEVEL_1_OR_2");return;}
    while(*cur&&isspace((unsigned char)*cur))cur++;
    if(*cur){ack(req,false,op,"EXTRA_ARGUMENT");return;}
    e5ResetTrace();e5Level=uint8_t(level);e5Boot=bootId;
    SPIporting::setE5WriteObserver(e5ObserveWrite);
    event("{\"event\":\"ACK\",\"request\":%lu,\"op\":\"E5SET\",\"ok\":true,"
          "\"role\":\"tag\",\"boot\":%lu,\"level\":%u,\"diag_rev\":\"R1J6_E5_ARM_TRACE_V1\"}",
          (unsigned long)req,(unsigned long)bootId,unsigned(e5Level));return;
  }
  if(strcmp(op,"E5INFO")==0){
    event("{\"event\":\"ACK\",\"request\":%lu,\"op\":\"E5INFO\",\"ok\":true,"
          "\"role\":\"tag\",\"diag_rev\":\"R1J6_E5_ARM_TRACE_V1\","
          "\"boot\":%lu,\"trace_boot\":%lu,\"trace_session\":%lu,"
          "\"session\":%lu,\"active\":%s,\"rx_armed\":%s,"
          "\"level\":%u,\"captured\":%s,\"count\":%u,\"write_count\":%u,"
          "\"write_seen\":%lu,\"snapshot_drops\":%u,\"write_drops\":%u}",
          (unsigned long)req,(unsigned long)bootId,(unsigned long)e5Boot,
          (unsigned long)e5Session,(unsigned long)sessionId,
          active?"true":"false",rxArmed?"true":"false",
          unsigned(e5Level),e5Captured?"true":"false",unsigned(e5N),unsigned(e5WN),
          (unsigned long)e5WriteCount,unsigned(e5SnapshotDrops),unsigned(e5WriteDrops));return;
  }
  if(strcmp(op,"E5ROW")==0){
    uint32_t i=0;if(!parseU32(cur,i)||i>=e5N){ack(req,false,op,"INDEX_OUT_OF_RANGE");return;}
    const E5Snapshot &s=e5Snapshots[i];
    event("{\"event\":\"ACK\",\"request\":%lu,\"op\":\"E5ROW\",\"ok\":true,"
          "\"role\":\"tag\",\"idx\":%lu,\"stage\":%u,\"level\":%u,"
          "\"t_us\":%llu,\"active\":%u,\"rx_armed\":%u,\"hw_ok\":%u,"
          "\"dev_id\":%lu,\"sys_time\":%llu,\"tx_antd\":%u,\"rx_antd\":%u,"
          "\"ctrl\":%u,\"ls\":%u,\"cs\":%u,\"write_seen\":%lu}",
          (unsigned long)req,(unsigned long)i,unsigned(s.stage),unsigned(s.level),
          (unsigned long long)s.stamp_us,unsigned(s.is_active),unsigned(s.is_rx_armed),
          unsigned(s.hw_good),(unsigned long)s.dev,(unsigned long long)s.sys,
          unsigned(s.tx),unsigned(s.rx),unsigned(s.gpio_ctrl),unsigned(s.gpio_ls),
          unsigned(s.gpio_cs),(unsigned long)s.write_seen);return;
  }
  if(strcmp(op,"E5WRITE")==0){
    uint32_t i=0;if(!parseU32(cur,i)||i>=e5WN){ack(req,false,op,"INDEX_OUT_OF_RANGE");return;}
    const E5Write &w=e5Writes[i];
    event("{\"event\":\"ACK\",\"request\":%lu,\"op\":\"E5WRITE\",\"ok\":true,"
          "\"role\":\"tag\",\"idx\":%lu,\"stage\":%u,\"t_us\":%llu,"
          "\"reg\":%u,\"off\":%u,\"nbytes\":%u,"
          "\"b0\":%u,\"b1\":%u,\"b2\":%u,\"b3\":%u}",
          (unsigned long)req,(unsigned long)i,unsigned(w.stage),(unsigned long long)w.stamp_us,
          unsigned(w.reg),unsigned(w.off),unsigned(w.nbytes),
          unsigned(w.value0),unsigned(w.value1),unsigned(w.value2),unsigned(w.value3));return;
  }
  if(strcmp(op,"HELLO")==0){refreshAntennaDelayReadback();event("{\"event\":\"ACK\",\"request\":%lu,\"op\":\"HELLO\",\"ok\":true,\"role\":\"%s\",\"boot\":%lu,\"firmware\":\"RF_PLATFORM_V1\",\"release\":\"R04\",\"profile\":\"RAWCAL_PAIR_R04_ABDIRECT\",\"hw_ok\":%s,\"baud\":%lu,\"ant_tx_requested\":%u,\"ant_rx_requested\":%u,\"ant_tx_readback\":%u,\"ant_rx_readback\":%u,\"ant_readback_ok\":%s,\"otp_ldo_tune\":%lu,\"ldo_before\":%lu,\"ldo_after\":%lu,\"ldo_kick_applied\":%s}",(unsigned long)req,role(),(unsigned long)bootId,hwOK?"true":"false",(unsigned long)currentBaud.load(),unsigned(IS_ANCHOR?cfg.ant_anchor:cfg.ant_tag),unsigned(IS_ANCHOR?cfg.ant_anchor:cfg.ant_tag),unsigned(antTxReadback),unsigned(antRxReadback),antReadbackOK?"true":"false",(unsigned long)DW1000Ng::getInitOtpLdoTune(),(unsigned long)DW1000Ng::getInitLdoTuneBefore(),(unsigned long)DW1000Ng::getInitLdoTuneAfter(),DW1000Ng::wasInitLdoTuneKicked()?"true":"false");return;}
  if(strcmp(op,"TIMESYNC")==0){const uint64_t t=nowUs();event("{\"event\":\"ACK\",\"request\":%lu,\"op\":\"TIMESYNC\",\"ok\":true,\"role\":\"tag\",\"boot\":%lu,\"esp_us\":%llu,\"diag_rev\":\"R1J\"}",(unsigned long)req,(unsigned long)bootId,(unsigned long long)t);return;}
  if(strcmp(op,"STATUS")==0){ack(req,true,op);return;}
  if(strcmp(op,"STOP")==0){
    active=false;remaining=0;
    if(e5Window)e5InArm=true;
    if(hwOK)idleRadio();e5Snap(12);
    if(!IS_ANCHOR){gR04TagResponseRouteOverride=R04_TAG_ROUTE_AUTO;selectRoute(ROUTE_A);r03TagReset();}
    e5Snap(13);e5InArm=false;e5Window=false;e6OnStop();
    ack(req,true,op);return;
  }
  if(strcmp(op,"CONFIG")==0){
    if(active){ack(req,false,op,"STOP_FIRST");return;}uint32_t sid,vals[CONFIG_FIELDS];Config c;
    if(!parseU32(cur,sid)||!sid){ack(req,false,op,"SESSION_REQUIRED");return;}
    for(unsigned i=0;i<CONFIG_FIELDS;i++)if(!parseU32(cur,vals[i])){ack(req,false,op,"19_VALUES_REQUIRED");return;}
    while(*cur&&isspace((unsigned char)*cur))cur++;if(*cur){ack(req,false,op,"EXTRA_ARGUMENT");return;}
    memcpy(&c,vals,sizeof(c));const char* why;if(!validConfig(c,why)){ack(req,false,op,why);return;}
    if(!hwOK){ack(req,false,op,"RADIO_NOT_READY");return;}
    if(!tagGuardCheck(tagdiag::ConfigBefore,0)){ack(req,false,op,"TAG_DIAG_PRECONFIG_FAILED");return;}cfg=c;sessionId=sid;peerBoot=0;txnId=0;gR04TagResponseRouteOverride=R04_TAG_ROUTE_AUTO;resetCiHistory();hwOK=applyRadio();const bool configReadback=tagGuardCheck(tagdiag::ConfigAfter,0);hwOK=hwOK&&configReadback;ack(req,hwOK,op,hwOK?"OK":"RADIO_HEALTH_FAILED");return;
  }
  if(strcmp(op,"ARM")==0){uint32_t sid,peer;if(active||!hwOK||!parseU32(cur,sid)||sid!=sessionId||!parseU32(cur,peer)||!peer){ack(req,false,op,"CONFIG_THEN_ARM_WITH_PEER_BOOT");return;}
    if(!tagGuardCheck(tagdiag::ArmBefore,0)){ack(req,false,op,"TAG_DIAG_PREARM_FAILED");return;}
    const bool e5ThisArm=(!IS_ANCHOR && e5Level!=0);
    if(e5ThisArm){e5ResetTrace();e5InArm=true;e5Window=true;e5Session=sid;e5Boot=bootId;e5Snap(1);}
    e6OnArm(sid);
    peerBoot=peer;txnId=0;resetCiHistory();active=true;remaining=0;
    if(!IS_ANCHOR){
      r03TagReset();e5Snap(2);
      idleRadio();e5Snap(3);
      selectRoute(0);e5Snap(4);
      e5Snap(5);armRx();e5Snap(11);
    }
    if(e5ThisArm){e5InArm=false;e5Captured=true;}
    if(!tagRxFault)tagGuardCheck(tagdiag::ArmAfter,0);
    e6OnArmDone();
    ack(req,!tagRxFault,op,tagRxFault?"TAG_RX_GUARD_LATCHED":"OK");return;}
  if(strcmp(op,"START")==0){uint32_t sid,count;if(!IS_ANCHOR||!active||!peerBoot||!parseU32(cur,sid)||sid!=sessionId||!parseU32(cur,count)||count<1||count>1000000){ack(req,false,op,"ARM_THEN_START_COUNT");return;}
    remaining=count;nextStart=nowUs()+200000;ack(req,true,op);return;}

  if(strcmp(op,"REMOTESTART")==0){
    uint32_t sid,count;
    if(IS_ANCHOR){ack(req,false,op,"TAG_ONLY");return;}
    if(!active||!peerBoot){ack(req,false,op,"ARM_FIRST");return;}
    if(!parseU32(cur,sid)||sid!=sessionId||!parseU32(cur,count)||count<1||count>1000000){ack(req,false,op,"SESSION_COUNT_REQUIRED");return;}
    while(*cur&&isspace((unsigned char)*cur))++cur;if(*cur){ack(req,false,op,"EXTRA_ARGUMENT");return;}
    bool ok=sendSessionStartBurst(count);
    ack(req,ok,op,ok?"OK":"SESSION_START_TX_FAILED");return;
  }
  if(r03TagCommand(req,op,cur))return;
  if(strcmp(op,"TXROUTE")==0){uint32_t v;if(remaining||r03TagPointActive){ack(req,false,op,"POINT_ACTIVE");return;}if(!parseU32(cur,v)||v>R04_TAG_ROUTE_AUTO){ack(req,false,op,"ROUTE_0_A_1_B_2_AUTO_REQUIRED");return;}gR04TagResponseRouteOverride=uint8_t(v);selectRoute(ROUTE_A);const uint8_t eff=effectiveFastRouteForTxn(cfg,txnId);event("{\"event\":\"ACK\",\"request\":%lu,\"op\":\"TXROUTE\",\"ok\":true,\"role\":\"tag\",\"route_override\":\"%s\",\"route_override_index\":%u,\"effective_fast_route\":\"%s\"}",(unsigned long)req,v==R04_TAG_ROUTE_AUTO?"AUTO":antRouteName(uint8_t(v)),unsigned(v),antRouteName(eff));return;}
  if(strcmp(op,"RXW4R")==0){uint32_t v;if(remaining||r03TagPointActive){ack(req,false,op,"POINT_ACTIVE");return;}if(!parseU32(cur,v)||v>1){ack(req,false,op,"0_OFF_1_ON_REQUIRED");return;}gTagW4R=(v==1);if(!gTagW4R)DW1000Ng::setWait4Response(0);
    event("{\"event\":\"ACK\",\"request\":%lu,\"op\":\"RXW4R\",\"ok\":true,\"role\":\"tag\",\"rx_w4r\":%s}",(unsigned long)req,gTagW4R?"true":"false");return;}
  if(strcmp(op,"TXROUTEINFO")==0){const uint8_t eff=effectiveFastRouteForTxn(cfg,txnId);event("{\"event\":\"ACK\",\"request\":%lu,\"op\":\"TXROUTEINFO\",\"ok\":true,\"role\":\"tag\",\"route_override\":\"%s\",\"route_override_index\":%u,\"effective_fast_route\":\"%s\"}",(unsigned long)req,gR04TagResponseRouteOverride==R04_TAG_ROUTE_AUTO?"AUTO":antRouteName(gR04TagResponseRouteOverride),unsigned(gR04TagResponseRouteOverride),antRouteName(eff));return;}
  if(strcmp(op,"TXPOWERREG")==0){uint8_t b[4]{};regRead(0x1E,0xFFFF,b,4);uint32_t v=le32(b);const uint8_t eff=effectiveFastRouteForTxn(cfg,txnId);event("{\"event\":\"ACK\",\"request\":%lu,\"op\":\"TXPOWERREG\",\"ok\":true,\"role\":\"tag\",\"tx_power_read\":%lu,\"route_override\":\"%s\",\"effective_fast_route\":\"%s\"}",(unsigned long)req,(unsigned long)v,gR04TagResponseRouteOverride==R04_TAG_ROUTE_AUTO?"AUTO":antRouteName(gR04TagResponseRouteOverride),antRouteName(eff));return;}
  if(uwbProvisionTagCommand(req,op,cur))return;
  if(strcmp(op,"BAUD")==0){uint32_t baud;if(active||!parseU32(cur,baud)||(baud!=921600&&baud!=2000000&&baud!=3000000)){ack(req,false,op,"STOP_FIRST_BAUD_921600_2000000_3000000");return;}
    OutMsg m;m.kind=3;m.baud=baud;snprintf(m.text,sizeof(m.text),"{\"event\":\"ACK\",\"request\":%lu,\"op\":\"BAUD\",\"ok\":true,\"role\":\"%s\",\"new_baud\":%lu}",(unsigned long)req,role(),(unsigned long)baud);
    ++outputPending;if(xQueueSend(outQ,&m,0)!=pdTRUE){--outputPending;++outputDrops;}return;}
  ack(req,false,op,"UNKNOWN_COMMAND");
}
static void serviceCommands(){
  static char buf[768];static unsigned pos=0;static bool overflow=false;
  while(Serial.available()){
    int c=Serial.read();if(c=='\r')continue;if(c=='\n'){if(!overflow){buf[pos]=0;command(buf);}pos=0;overflow=false;continue;}
    if(pos+1<sizeof(buf))buf[pos++]=char(c);else overflow=true;
  }
}
static void setupDevice(){
  Serial.setRxBufferSize(2048);Serial.setTxBufferSize(8192);Serial.begin(INITIAL_BAUD);delay(300);
  outQ=xQueueCreate(32,sizeof(OutMsg));freeQ=xQueueCreate(POOL_N,sizeof(uint8_t));
  if(!outQ||!freeQ){Serial.println("FATAL_QUEUE");while(true)delay(1000);}
  for(uint8_t i=0;i<POOL_N;i++)xQueueSend(freeQ,&i,0);
  if(xTaskCreatePinnedToCore(writerTask,"rf_writer",10000,nullptr,1,nullptr,0)!=pdPASS){Serial.println("FATAL_WRITER");while(true)delay(1000);}
  bootId=esp_random();if(!bootId)bootId=1;
  pinMode(IRQ,INPUT);pinMode(CS,OUTPUT);digitalWrite(CS,HIGH);
  // Explicit native SPI pins before the library's SPI.begin(). Never repurpose GPIO5 as SS.
  SPIporting::bindRxState(&rxArmed);SPI.begin(18,19,23,CS);DW1000Ng::initializeNoInterrupt(CS,RST);SPIporting::setSPIspeed(SPIClock::FAST);
  platformLoadPersisted(false);
  hwOK=healthy();if(hwOK)hwOK=applyRadio();
  event("{\"event\":\"BOOT\",\"role\":\"%s\",\"boot\":%lu,\"hw_ok\":%s,\"firmware\":\"RF_PLATFORM_V1\",\"release\":\"R04\",\"auto_start\":false,\"otp_ldo_tune\":%lu,\"ldo_before\":%lu,\"ldo_after\":%lu,\"ldo_kick_applied\":%s}",role(),(unsigned long)bootId,hwOK?"true":"false",(unsigned long)DW1000Ng::getInitOtpLdoTune(),(unsigned long)DW1000Ng::getInitLdoTuneBefore(),(unsigned long)DW1000Ng::getInitLdoTuneAfter(),DW1000Ng::wasInitLdoTuneKicked()?"true":"false");
}
static void loopDevice(){
  serviceCommands();
  e6Periodic();
  if(rxDiagFollowupMs&&int32_t(millis()-rxDiagFollowupMs)>=0){rxDiagFollowupMs=0;emitStartRxDiag("after_100ms");}
  if(active&&hwOK){
    if(IS_ANCHOR){
      if(remaining&&nowUs()>=nextStart){
        runAnchor(txnId++);--remaining;uint32_t nextGap=cfg.period_us;nextStart+=nextGap;
        if(nowUs()>=nextStart){++periodMiss;nextStart=nowUs()+nextGap;}
        if(!remaining){active=false;event("{\"event\":\"RUN_DONE\",\"role\":\"anchor\",\"session\":%lu,\"attempts\":%lu}",(unsigned long)sessionId,(unsigned long)txnId);}
      }
    }else {
      uint8_t desiredRoute=ROUTE_A;
      if(r03TagPointActive){
        const uint32_t physical=(cfg.mode==6)?(r03TagCount*2U):r03TagCount;
        const bool pointRfDone=txnId>=r03TagFirstTxn+physical;
        if(!pointRfDone&&cfg.mode!=4)desiredRoute=effectiveFastRouteForTxn(cfg,txnId);
      }
      if(route!=desiredRoute){idleRadio();selectRoute(desiredRoute);}
      AirPacket p{};RxObs o{};int got=pollPacket(p,o);
      if(got==1){
        if(r03TagHandleAir(p,o)){/* control frame consumed */}
        else {uint8_t first=cfg.mode==4?A1:POLL;
          if(p.h.type==first&&p.h.txn>=txnId){txnId=p.h.txn+1;runTag(p,o);}
          else {++unexpected;finishRx();}
        }
      }
      if(rxArmed&&nowUs()-armedAt>2000000){e6OnStale();idleRadio();selectRoute(0);}
    }
  }
  if(millis()-lastHeartbeat>=1000){lastHeartbeat=millis();event("{\"event\":\"HEARTBEAT\",\"role\":\"%s\",\"boot\":%lu,\"session\":%lu,\"active\":%s,\"hw_ok\":%s,\"esp_us\":%llu,\"diag_rev\":\"R1J\",\"tx_timeout\":%lu,\"rx_timeout\":%lu,\"rx_error\":%lu,\"bad_air\":%lu,\"unexpected\":%lu,\"period_miss\":%lu,\"output_drop\":%lu,\"resource_drop\":%lu,\"out_pending\":%lu,\"heap\":%lu}",role(),(unsigned long)bootId,(unsigned long)sessionId,active?"true":"false",hwOK?"true":"false",(unsigned long long)nowUs(),(unsigned long)txTimeouts,(unsigned long)rxTimeouts,(unsigned long)rxErrors,(unsigned long)badAir,(unsigned long)unexpected,(unsigned long)periodMiss,(unsigned long)outputDrops.load(),(unsigned long)resourceDrops.load(),(unsigned long)outputPending.load(),(unsigned long)ESP.getFreeHeap());}
  // Let the idle task run without a 1 ms sleep in each critical RX polling iteration.
  // Transaction functions are bounded. This yield is outside their timing-critical exchange.
  static uint32_t lastIdleYield=0;
  if(!active || millis()-lastIdleYield>=250){lastIdleYield=millis();delay(1);}else delayMicroseconds(20);
}
} // namespace bench

