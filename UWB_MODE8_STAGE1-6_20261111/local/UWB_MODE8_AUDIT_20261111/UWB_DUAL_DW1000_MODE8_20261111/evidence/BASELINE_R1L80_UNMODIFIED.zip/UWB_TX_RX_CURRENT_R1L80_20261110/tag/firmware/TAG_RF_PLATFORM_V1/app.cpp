#define BENCH_ANCHOR 0
#include "bench_impl.hpp"
void benchSetup(){bench::setupDevice();}
void benchLoop(){bench::loopDevice();}
