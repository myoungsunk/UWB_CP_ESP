#pragma once
#include <stdint.h>
#include <stddef.h>
namespace tagdiag {
constexpr const char* CANDIDATE="R1K8_R1L80";
enum Stage : uint8_t { GuardFault=30, ConfigBefore=32, ConfigAfter=33,
  ArmBefore=34, ArmAfter=35, ControlBefore=36, ControlPrepared=37,
  ControlWait=38, ControlDone=39, ControlRearmed=40,
  E0Before=41,E0After=42,F0Before=43,F0After=44, RxStatus=45 };
struct Record {
  uint64_t begin_us=0,end_us=0,status=0,trigger_status=0,time_a=0,time_b=0,tx_hw=0;
  uint32_t spi_clock=0,spi_ctrl2=0;
  uint32_t seq=0,boot=0,session=0,dev=0,detail=0;
  uint16_t tx=0,rx=0;
  uint8_t stage=0,kind=0,active=0,rx_armed=0; // kind: 0 marker, 1 registers, 2 guard
  bool bad=false;
};
template<size_t N> struct Trace {
  static_assert(N>0,"nonempty trace");
  Record records[N]{};size_t head=0,count=0;uint32_t total=0,overwrites=0;
  bool frozen=false;Record first{};
  void push(Record r){
    if(frozen)return;
    r.seq=total++;
    size_t at=(head+count)%N;
    if(count==N){at=head;head=(head+1)%N;++overwrites;}else ++count;
    records[at]=r;
    if(r.bad){first=r;frozen=true;}
  }
  const Record* get(size_t i)const{return i<count?&records[(head+i)%N]:nullptr;}
};
constexpr uint64_t MASK40=0xffffffffffULL;
constexpr uint64_t TX_DONE=uint64_t(1)<<7;
constexpr bool statusTrusted(uint64_t s){return s<=MASK40 && s!=MASK40 && !(s&((uint64_t(1)<<24)|(uint64_t(1)<<25)));}
constexpr bool timestampTrusted(uint64_t t){return t>0 && t<MASK40;}
constexpr bool txComplete(uint64_t status,uint64_t stamp){return statusTrusted(status) && (status&TX_DONE) && timestampTrusted(stamp);}
}

