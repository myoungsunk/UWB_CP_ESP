#pragma once

// R03 route-session control for the Tag. The Tag stays connected to the Pi by USB.
// Point control is exchanged over UWB while POLL/RESP/A1/B/A2 measurement code remains unchanged.

constexpr uint32_t R03_POINT_MAX_RECORDS_HARD = 64;
constexpr uint32_t R04_PAIR_MAX_LOGICAL_SAMPLES = 32;
constexpr uint32_t R03_CTRL_TIMEOUT_MS = 2500;
static bool r03TagPointActive=false,r03TagAwaitCommit=false;
static uint32_t r03TagPoint=0,r03TagAttempt=0,r03TagCount=0,r03TagFirstTxn=0;
static uint32_t r03TagLastCommitPoint=0,r03TagLastCommitAttempt=0,r03TagLastCommitCount=0,r03TagLastCommitCrc=0,r03TagLastCommitFirstTxn=0;

static uint32_t r1lTagLastCommitBlocks=0;static bool r1lTagLastCommitNoStore=false;

static void r03TagReset(){r03TagPointActive=false;r03TagAwaitCommit=false;r03TagPoint=r03TagAttempt=r03TagCount=r03TagFirstTxn=0;}

static bool r03TagSendControl(uint8_t type,uint32_t pointId,uint64_t ts0=0,uint64_t ts1=0,uint64_t ts2=0){
  if(tagRxFault||IS_ANCHOR||!sessionId||!peerBoot)return false;
  if(!tagGuardCheck(tagdiag::ControlBefore,0))return false;
  idleRadio();selectRoute(0);waitSwitch();AirPacket p{};
  p.h.type=type;p.h.session=sessionId;p.h.txn=pointId;p.h.config_id=configId(cfg);p.h.boot=bootId;
  p.ts[0]=ts0;p.ts[1]=ts1;p.ts[2]=ts2;byte data[54]{};uint16_t n=uint16_t(encodeAir(p,data));
  DW1000Ng::setTransmitData(data,n);
  if(!tagGuardCheck(tagdiag::ControlPrepared,0))return false;
  uint64_t t0=nowUs();DW1000Ng::startTransmit(TransmitMode::IMMEDIATE);
  uint64_t txStatus=0;
  for(;;){
    txStatus=status40();
    if(!tagDiagTxStatus(txStatus,0,false))return false;
    if(txStatus&tagdiag::TX_DONE)break;
    if(nowUs()-t0>uint64_t(cfg.rx_grace_us)+8000ULL){++txTimeouts;idleRadio();event("{\"event\":\"R03_CTRL_TX\",\"role\":\"tag\",\"type\":\"%s\",\"point\":%lu,\"ok\":false}",typeName(type),(unsigned long)pointId);return false;}delayMicroseconds(10);
  }
  uint64_t doneUs=nowUs();uint8_t txRoute=route,txCtrl=digitalRead(CTRL),txLs=digitalRead(LS);
  uint64_t hw=DW1000Ng::getTransmitTimestamp()&MASK40;uint64_t stampEndUs=nowUs();
  char doneRaw[11]{};for(unsigned k=0;k<5;k++)snprintf(doneRaw+k*2,3,"%02x",unsigned((txStatus>>(8*k))&255));
  if(!tagDiagTxStatus(txStatus,hw,true))return false;
  if(!tagGuardCheck(tagdiag::ControlDone,txStatus))return false;
  tagClearTxStatus();idleRadio();selectRoute(0);armRx();
  if(tagRxFault||!tagGuardCheck(tagdiag::ControlRearmed,0))return false;
  event("{\"event\":\"POINT_TX_DIAG\",\"version\":\"CONTROL100_V1\",\"boot\":%lu,\"session\":%lu,\"point\":%lu,\"type\":\"%s\",\"tx_start_us\":%llu,\"done_read_end_us\":%llu,\"timestamp_read_end_us\":%llu,\"tx_hw\":%llu,\"status_raw_hex\":\"%s\",\"status_le_hex\":\"%010llx\",\"status_source\":\"TX_DONE_poll_same_5_bytes\",\"antenna_route\":%u,\"ctrl\":%u,\"ls\":%u}",(unsigned long)bootId,(unsigned long)sessionId,(unsigned long)pointId,typeName(type),(unsigned long long)t0,(unsigned long long)doneUs,(unsigned long long)stampEndUs,(unsigned long long)hw,doneRaw,(unsigned long long)txStatus,txRoute,txCtrl,txLs);
  event("{\"event\":\"R03_CTRL_TX\",\"role\":\"tag\",\"type\":\"%s\",\"route\":%lu,\"point\":%lu,\"tx_hw\":%llu,\"bytes\":%u,\"ok\":true}",typeName(type),(unsigned long)sessionId,(unsigned long)pointId,(unsigned long long)hw,unsigned(n));return true;
}

static bool r03TagWaitControl(uint8_t wanted,uint32_t pointId,uint32_t attempt,AirPacket& out,uint32_t timeoutMs=R03_CTRL_TIMEOUT_MS){
  selectRoute(0);armRx();uint32_t t0=millis();
  while(millis()-t0<timeoutMs){if(tagRxFault)return false;AirPacket p{};RxObs o{};int got=pollPacket(p,o);if(got==1){if(p.h.type==wanted&&p.h.txn==pointId){uint32_t gotAttempt=(wanted==ROUTE_END_ACK)?0:uint32_t(p.ts[0]>>32);if(wanted==ROUTE_END_ACK||gotAttempt==attempt){diagnostics(o);finishRx();out=p;event("{\"event\":\"R03_CTRL_RX\",\"role\":\"tag\",\"type\":\"%s\",\"route\":%lu,\"point\":%lu,\"rx_hw\":%llu}",typeName(wanted),(unsigned long)p.h.session,(unsigned long)p.h.txn,(unsigned long long)o.hw);return true;}}++unexpected;finishRx();armRx();}else if(got<0)armRx();delayMicroseconds(50);}idleRadio();return false;
}

static void r03TagRecordCommit(const AirPacket& p){
  uint32_t attempt=uint32_t(p.ts[0]>>32),count=uint32_t(p.ts[0]&0xffffffffULL);r03TagLastCommitPoint=p.h.txn;r03TagLastCommitAttempt=attempt;r03TagLastCommitCount=count;r03TagLastCommitCrc=uint32_t(p.ts[1]);r03TagLastCommitFirstTxn=uint32_t(p.ts[2]);
  // R1L: ts[1] bits 32..47 = probe blocks the Anchor sent, bit 63 = Anchor store=0 (crc32 is then the block CRC).
  r1lTagLastCommitBlocks=uint32_t((p.ts[1]>>32)&0xFFFFU);r1lTagLastCommitNoStore=((p.ts[1]>>63)&1ULL)!=0;
  const bool matching=(p.h.txn==r03TagPoint&&attempt==r03TagAttempt);
  const uint32_t tagCrc=gR1LTagPointCrc^0xFFFFFFFFUL;
  const char* blockCheck=!matching?"NOT_CURRENT_POINT":(r1lTagLastCommitBlocks!=gR1LTagPointBlocks?"COUNT_MISMATCH":(!r1lTagLastCommitNoStore?(gR1LTagPointBlocks?"COUNT_OK_CRC_IN_FLASH":"NO_PROBE_BLOCKS"):(tagCrc==r03TagLastCommitCrc?"CRC_OK":"CRC_MISMATCH")));
  if(matching){r03TagPointActive=false;r03TagAwaitCommit=false;}
  event("{\"event\":\"R03_POINT_COMMIT_RX\",\"role\":\"tag\",\"route\":%lu,\"point\":%lu,\"attempt\":%lu,\"records\":%lu,\"first_txn\":%lu,\"crc32\":%lu,\"matching_active_point\":%s,\"anchor_store\":%u,\"anchor_blocks\":%lu,\"tag_blocks\":%lu,\"tag_block_crc32\":%lu,\"block_check\":\"%s\"}",(unsigned long)p.h.session,(unsigned long)p.h.txn,(unsigned long)attempt,(unsigned long)count,(unsigned long)r03TagLastCommitFirstTxn,(unsigned long)r03TagLastCommitCrc,matching?"true":"false",r1lTagLastCommitNoStore?0U:1U,(unsigned long)r1lTagLastCommitBlocks,(unsigned long)gR1LTagPointBlocks,(unsigned long)tagCrc,blockCheck);
}

static bool r03TagHandleAir(AirPacket& p,RxObs& o){
  if(p.h.type==POINT_COMMIT){diagnostics(o);finishRx();r03TagRecordCommit(p);selectRoute(0);armRx();return true;}
  if(p.h.type==ROUTE_END_ACK){diagnostics(o);finishRx();event("{\"event\":\"R03_ROUTE_END_ACK_RX\",\"role\":\"tag\",\"route\":%lu,\"committed_points\":%lu,\"total_records\":%lu}",(unsigned long)p.h.session,(unsigned long)p.ts[0],(unsigned long)p.ts[1]);return true;}
  return false;
}

static void r03TagEmitStatus(uint32_t req,const char* op){
  event("{\"event\":\"ACK\",\"request\":%lu,\"op\":\"%s\",\"ok\":true,\"role\":\"tag\",\"r03\":true,\"route\":%lu,\"active\":%s,\"point_active\":%s,\"await_commit\":%s,\"point\":%lu,\"attempt\":%lu,\"count\":%lu,\"first_txn\":%lu,\"next_txn\":%lu,\"last_commit_point\":%lu,\"last_commit_attempt\":%lu,\"last_commit_count\":%lu,\"last_commit_crc32\":%lu}",(unsigned long)req,op,(unsigned long)sessionId,active?"true":"false",r03TagPointActive?"true":"false",r03TagAwaitCommit?"true":"false",(unsigned long)r03TagPoint,(unsigned long)r03TagAttempt,(unsigned long)r03TagCount,(unsigned long)r03TagFirstTxn,(unsigned long)txnId,(unsigned long)r03TagLastCommitPoint,(unsigned long)r03TagLastCommitAttempt,(unsigned long)r03TagLastCommitCount,(unsigned long)r03TagLastCommitCrc);
}

static bool r03TagCommand(uint32_t req,const char* op,char*& cur){
  if(strcmp(op,"ROUTESTATUS")==0){r03TagEmitStatus(req,op);return true;}
  if(strcmp(op,"R1LINFO")==0){
    event("{\"event\":\"ACK\",\"request\":%lu,\"op\":\"R1LINFO\",\"ok\":true,\"role\":\"tag\",\"r1l\":1,\"block_version\":%u,\"block_bytes\":%u,\"point_blocks\":%lu,\"point_block_crc32\":%lu,\"blocks_total\":%lu,\"block_copy_mismatch_total\":%lu,\"last_commit_anchor_blocks\":%lu,\"last_commit_anchor_store\":%u,\"ctrl_handshake\":2}",
      (unsigned long)req,unsigned(R1L_BLOCK_VERSION),unsigned(R1L_BLOCK_BYTES),(unsigned long)gR1LTagPointBlocks,(unsigned long)(gR1LTagPointCrc^0xFFFFFFFFUL),(unsigned long)gR1LTagBlocksTotal,(unsigned long)gR1LTagBlockMismatch,(unsigned long)r1lTagLastCommitBlocks,r1lTagLastCommitNoStore?0U:1U);return true;}
  if(strcmp(op,"ROUTEPING")==0){
    if(!active||!peerBoot){ack(req,false,op,"ARM_FIRST");return true;}
    if(r03TagPointActive||r03TagAwaitCommit){ack(req,false,op,"POINT_BUSY");return true;}
    if(!r03TagSendControl(POINT_QUERY,0,0,0,0)){ack(req,false,op,"ROUTE_PROBE_TX_FAILED");return true;}
    AirPacket reply{};bool ok=r03TagWaitControl(POINT_COMMIT,0,0,reply,1000)&&reply.ts[0]==0&&reply.ts[2]==1;
    selectRoute(0);armRx();
    if(!ok){ack(req,false,op,"ROUTE_NOT_READY");return true;}
    event("{\"event\":\"ACK\",\"request\":%lu,\"op\":\"ROUTEPING\",\"role\":\"tag\",\"ok\":true,\"ready\":true,\"route\":%lu,\"config_id\":%lu,\"boot\":%lu,\"peer_boot\":%lu,\"next_txn\":%lu}",
      (unsigned long)req,(unsigned long)sessionId,(unsigned long)configId(cfg),(unsigned long)bootId,(unsigned long)reply.h.boot,(unsigned long)reply.ts[1]);return true;
  }
  if(strcmp(op,"POINTSTART")==0){
    uint32_t point,attempt,count;if(!active||!peerBoot){ack(req,false,op,"ARM_FIRST");return true;}if(r03TagPointActive||r03TagAwaitCommit){ack(req,false,op,"PREVIOUS_POINT_NOT_COMMITTED");return true;}const uint32_t maxCount=(cfg.mode==6)?R04_PAIR_MAX_LOGICAL_SAMPLES:R03_POINT_MAX_RECORDS_HARD;if(!parseU32(cur,point)||!parseU32(cur,attempt)||!parseU32(cur,count)||!point||!attempt||count<1||count>maxCount){ack(req,false,op,cfg.mode==6?"MODE6_LOGICAL_COUNT_1_32_REQUIRED":"POINT_ATTEMPT_COUNT_1_64_REQUIRED");return true;}
    uint64_t a=(uint64_t(attempt)<<32)|uint64_t(count);if(!r03TagSendControl(POINT_START,point,a,uint64_t(txnId),0)){ack(req,false,op,"POINT_START_TX_FAILED");return true;}AirPacket accept{};if(!r03TagWaitControl(POINT_ACCEPT,point,attempt,accept)){ack(req,false,op,"POINT_ACCEPT_TIMEOUT");selectRoute(0);armRx();return true;}
    uint32_t acceptedCount=uint32_t(accept.ts[0]&0xffffffffULL),firstTxn=uint32_t(accept.ts[1]);if(acceptedCount!=count){ack(req,false,op,"POINT_ACCEPT_COUNT_MISMATCH");selectRoute(0);armRx();return true;}
    // R1K8: Anchor handshake v2 starts measurement only after POINT_READY.
    // Send once with the accepted first transaction; never retry or clear a guard.
    if(!r03TagSendControl(POINT_READY,point,a,uint64_t(firstTxn),0)){idleRadio();ack(req,false,op,"POINT_READY_TX_FAILED");return true;}
    r03TagPoint=point;r03TagAttempt=attempt;r03TagCount=count;r03TagFirstTxn=firstTxn;r03TagPointActive=true;r03TagAwaitCommit=true;txnId=firstTxn;resetCiHistory();r1lTagPointReset();selectRoute(cfg.mode==4?ROUTE_A:effectiveFastRouteForTxn(cfg,txnId));armRx();
    event("{\"event\":\"R03_POINT_ACCEPTED\",\"role\":\"tag\",\"route\":%lu,\"point\":%lu,\"attempt\":%lu,\"count\":%lu,\"first_txn\":%lu}",(unsigned long)sessionId,(unsigned long)point,(unsigned long)attempt,(unsigned long)count,(unsigned long)firstTxn);ack(req,true,op);return true;
  }
  if(strcmp(op,"POINTQUERY")==0){
    uint32_t point,attempt;if(!active||!peerBoot){ack(req,false,op,"ARM_FIRST");return true;}if(!parseU32(cur,point)||!parseU32(cur,attempt)||!point||!attempt){ack(req,false,op,"POINT_ATTEMPT_REQUIRED");return true;}if(!r03TagSendControl(POINT_QUERY,point,uint64_t(attempt),0,0)){ack(req,false,op,"POINT_QUERY_TX_FAILED");return true;}AirPacket commit{};if(!r03TagWaitControl(POINT_COMMIT,point,attempt,commit)){ack(req,false,op,"POINT_COMMIT_TIMEOUT");selectRoute(0);armRx();return true;}r03TagRecordCommit(commit);selectRoute(0);armRx();ack(req,true,op);return true;
  }
  if(strcmp(op,"ROUTEEND")==0){
    // R1F: "ROUTEEND <req> 1" forces route termination when the Tag-side point state is stuck
    // (Anchor already committed its point; Tag discards its uncommitted view). Default unchanged.
    uint32_t force=0;parseU32(cur,force);
    if(!active||!peerBoot){ack(req,false,op,"ARM_FIRST");return true;}
    if((r03TagPointActive||r03TagAwaitCommit)&&force!=1){ack(req,false,op,"POINT_NOT_COMMITTED");return true;}
    if(force==1&&(r03TagPointActive||r03TagAwaitCommit)){event("{\"event\":\"R1F_ROUTE_END_FORCED\",\"role\":\"tag\",\"route\":%lu,\"point\":%lu,\"attempt\":%lu,\"next_txn\":%lu}",(unsigned long)sessionId,(unsigned long)r03TagPoint,(unsigned long)r03TagAttempt,(unsigned long)txnId);r03TagPointActive=false;r03TagAwaitCommit=false;}
    if(!r03TagSendControl(ROUTE_END,0,uint64_t(txnId),0,0)){ack(req,false,op,"ROUTE_END_TX_FAILED");return true;}AirPacket end{};if(!r03TagWaitControl(ROUTE_END_ACK,0,0,end,4000)){ack(req,false,op,"ROUTE_END_ACK_TIMEOUT");return true;}event("{\"event\":\"R03_ROUTE_END_ACK_RX\",\"role\":\"tag\",\"route\":%lu,\"committed_points\":%lu,\"total_records\":%lu}",(unsigned long)sessionId,(unsigned long)end.ts[0],(unsigned long)end.ts[1]);active=false;idleRadio();selectRoute(0);ack(req,true,op);return true;
  }
  return false;
}
