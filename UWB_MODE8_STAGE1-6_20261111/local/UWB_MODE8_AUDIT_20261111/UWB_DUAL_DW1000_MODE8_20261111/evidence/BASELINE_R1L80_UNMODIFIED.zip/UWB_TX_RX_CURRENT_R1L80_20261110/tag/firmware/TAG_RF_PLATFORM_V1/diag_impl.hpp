// Tag-only, included before rx_guard_impl.hpp. No writes or output in capture.
static bool parseU32(char*& cur,uint32_t& value);
static void ack(uint32_t req,bool ok,const char* op,const char* why);
static tagdiag::Record tagDiagBase(uint8_t stage,uint8_t kind){
  tagdiag::Record r;r.begin_us=nowUs();r.stage=stage;r.kind=kind;
  r.boot=bootId;r.session=sessionId;r.active=active;r.rx_armed=rxArmed;return r;
}
static void tagDiagMarker(uint8_t stage,uint32_t detail=0,uint64_t status=0){
  if(tagDiag.frozen)return;
  auto r=tagDiagBase(stage,0);r.detail=detail;r.status=status;r.end_us=nowUs();tagDiag.push(r);
}
static void tagDiagFault(uint8_t reason,uint64_t status,uint8_t stage){
  if(tagDiag.frozen)return;
  auto r=tagDiagBase(stage,2);r.status=status;r.detail=reason;r.bad=true;
  r.end_us=nowUs();tagDiag.push(r);
}
static bool tagDiagSnapshot(uint8_t stage,uint64_t trigger){
  if(tagDiag.frozen||tagRxFault)return false;
  auto r=tagDiagBase(stage,1);uint8_t d[4]{},a[5]{},b[5]{},tx[2]{},rx[2]{},ss[5]{};
  regRead(0,0xFFFF,d,4);regRead(6,0xFFFF,a,5);
  regRead(0x18,0xFFFF,tx,2);regRead(0x2E,0x1804,rx,2);
  regRead(0x0F,0xFFFF,ss,5);regRead(6,0xFFFF,b,5);
  r.dev=tagCheckDev=le32(d);r.tx=tagCheckTx=le16(tx);r.rx=tagCheckRx=le16(rx);
  r.time_a=tagCheckTimeA=le40(a);r.time_b=tagCheckTimeB=le40(b);
  r.spi_clock=SPI.getClockDivider();r.spi_ctrl2=SPIporting::lastTransactionCtrl2();
  r.status=le40(ss);r.trigger_status=trigger;r.end_us=nowUs();
  r.bad=!tagdiag::statusTrusted(r.status)||!rxguard::goodSnapshot(r.dev,r.tx,r.rx,uint16_t(cfg.ant_tag),r.time_a,r.time_b);
  tagDiag.push(r);
  // Retain the original E6 diagnostic channel, independent of the C2 ring.
  // Freeze C2 before E6's guard callback or any best-effort shutdown write.
  e6AuditCapture(20,d,a,tx,rx,ss,3);
  return !r.bad&&!tagRxFault;
}
static bool tagDiagTxStatus(uint64_t status,uint64_t stamp,bool hasStamp){
  if(tagRxFault||tagDiag.frozen)return false;
  auto r=tagDiagBase(hasStamp?tagdiag::ControlDone:tagdiag::ControlWait,0);
  r.status=status;r.tx_hw=stamp;r.detail=hasStamp?1:0;
  r.bad=!tagdiag::statusTrusted(status)||(hasStamp&&!tagdiag::txComplete(status,stamp));
  r.end_us=nowUs();
  // Do not fill the trace with an idle TX wait loop; retain completion or fault.
  if(r.bad||hasStamp)tagDiag.push(r);
  if(r.bad){tagGuardTrip(5,status,r.stage);return false;}
  return true;
}
static void tagDiagEmit(uint32_t req,uint32_t i,const tagdiag::Record& r){
  event("{\"event\":\"ACK\",\"request\":%lu,\"op\":\"STAGETRACE\",\"ok\":true,\"role\":\"tag\",\"idx\":%lu,\"seq\":%lu,\"boot\":%lu,\"session\":%lu,\"spi_clock\":%lu,\"spi_ctrl2\":%lu,\"stage\":%u,\"kind\":%u,\"begin_us\":%llu,\"end_us\":%llu,\"status\":%llu,\"trigger_status\":%llu,\"dev\":%lu,\"tx\":%u,\"rx\":%u,\"time_a\":%llu,\"time_b\":%llu,\"tx_hw\":%llu,\"detail\":%lu,\"active\":%u,\"rx_armed\":%u,\"bad\":%s}",
    (unsigned long)req,(unsigned long)i,(unsigned long)r.seq,(unsigned long)r.boot,(unsigned long)r.session,(unsigned long)r.spi_clock,(unsigned long)r.spi_ctrl2,unsigned(r.stage),unsigned(r.kind),(unsigned long long)r.begin_us,(unsigned long long)r.end_us,(unsigned long long)r.status,(unsigned long long)r.trigger_status,(unsigned long)r.dev,unsigned(r.tx),unsigned(r.rx),(unsigned long long)r.time_a,(unsigned long long)r.time_b,(unsigned long long)r.tx_hw,(unsigned long)r.detail,unsigned(r.active),unsigned(r.rx_armed),r.bad?"true":"false");
}
static bool tagDiagCommand(uint32_t req,const char* op,char*& cur){
  if(postFaultCommand(req,op,cur))return true;
  if(strcmp(op,"STAGEINFO")==0){
    event("{\"event\":\"ACK\",\"request\":%lu,\"op\":\"STAGEINFO\",\"ok\":true,\"role\":\"tag\",\"candidate\":\"%s\",\"boot\":%lu,\"session\":%lu,\"count\":%u,\"capacity\":96,\"total\":%lu,\"overwrites\":%lu,\"frozen\":%s,\"first_seq\":%lu,\"first_stage\":%u,\"first_kind\":%u,\"first_begin_us\":%llu,\"first_end_us\":%llu,\"guard_latched\":%s}",
      (unsigned long)req,tagdiag::CANDIDATE,(unsigned long)bootId,(unsigned long)sessionId,unsigned(tagDiag.count),(unsigned long)tagDiag.total,(unsigned long)tagDiag.overwrites,tagDiag.frozen?"true":"false",(unsigned long)tagDiag.first.seq,unsigned(tagDiag.first.stage),unsigned(tagDiag.first.kind),(unsigned long long)tagDiag.first.begin_us,(unsigned long long)tagDiag.first.end_us,tagRxFault?"true":"false");return true;
  }
  if(strcmp(op,"STAGETRACE")==0){
    uint32_t i=0;if(!parseU32(cur,i)||i>=tagDiag.count){ack(req,false,op,"INDEX_OUT_OF_RANGE");return true;}
    tagDiagEmit(req,i,*tagDiag.get(i));return true;
  }
  return false;
}
