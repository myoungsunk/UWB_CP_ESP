// Included inside namespace bench after E6 capture definitions. Tag only.
static_assert(!IS_ANCHOR,"This candidate is Tag-only; do not build for Anchor");
static void tagClearMask(uint64_t mask){
  uint8_t bytes[5];for(unsigned i=0;i<5;++i)bytes[i]=uint8_t(mask>>(8*i));
  regWrite(0x0F,0xFFFF,bytes,5); // explicit W1C bits, never cached SYS_STATUS
}
static void tagClearTxStatus(){if(!tagRxFault)tagClearMask(rxguard::TX_CLEAR);}
static void tagGuardTrip(uint8_t reason,uint64_t status,uint8_t stage){
  if(tagRxFault)return;
  tagDiagFault(reason,status,stage);
  tagRxFault=true;tagFaultReason=reason;tagFaultStage=stage;
  tagFaultUs=nowUs();tagFaultStatus=status;
  e6Event(20,reason,stage); // freeze first guard record before the only shutdown write
  hwOK=false;
  // Best effort only: SPI failure prevents claiming physical shutdown confirmation.
  DW1000Ng::forceTRxOff();rxArmed=false;tagShutdownAttempted=true;
  postFaultCapture(); // bounded read-only capture after latch and shutdown attempt
  // Keep logical active until the operator's guarded STOP; do not reset route/trace.
}
static bool tagGuardCheck(uint8_t stage,uint64_t status){
  if(tagRxFault)return false;
  if(!tagDiagSnapshot(stage,status)){
    tagGuardTrip(2,status,stage);return false;
  }
  return true;
}
static bool tagRecoverRx(uint64_t status,uint8_t code){
  if(!tagGuardCheck(2,status))return false;
  ++rxErrors;gLastRejectCode=code;gLastRejectStatus=status;
  e6OnRxError(code,status);gLastRejectHw=tagCheckTimeB;
  tagClearMask(status&rxguard::RX_CLEAR);
  DW1000Ng::forceTRxOff();rxArmed=false;
  // Preserve the pinned library's RX-only E0/F0 sequence for validated errors.
  // This candidate does not remove receiver resets or silently restore ANTD.
  uint8_t low=0xE0,high=0xF0;
  tagDiagMarker(tagdiag::E0Before);regWrite(0x36,3,&low,1);tagDiagMarker(tagdiag::E0After);
  tagDiagMarker(tagdiag::F0Before);regWrite(0x36,3,&high,1);tagDiagMarker(tagdiag::F0After);
  ++tagValidatedResets;
  return tagGuardCheck(3,status); // rearm only after verified readback and clock progress
}
