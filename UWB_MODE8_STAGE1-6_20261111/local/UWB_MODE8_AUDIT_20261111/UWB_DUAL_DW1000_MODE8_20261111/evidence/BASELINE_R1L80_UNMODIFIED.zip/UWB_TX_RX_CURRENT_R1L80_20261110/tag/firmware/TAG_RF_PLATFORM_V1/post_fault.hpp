static bool parseU32(char*& cur,uint32_t& value);
static void ack(uint32_t req,bool ok,const char* op,const char* why);
struct PostFaultRead { uint64_t start=0,end=0; uint32_t clock=0,ctrl2=0; uint8_t raw[5]{}; };
static constexpr uint8_t pfReg[6]={0,15,40,15,15,0};
static constexpr uint16_t pfSub[6]={65535,65535,44,65535,65535,65535};
static constexpr uint8_t pfLen[6]={4,5,4,5,5,4};
static PostFaultRead postFaultReads[6]{},postBaselineReads[6]{};
static bool postFaultCaptured=false,postBaselineCaptured=false;
static uint32_t pfGapUs=0,pfWaitUs=0;
static void postReadSix(PostFaultRead* records){
  SPIporting::RxSpeedScope scope(true);
  SPIporting::setProbeTiming(2000000,2,0);
  if(pfWaitUs)delayMicroseconds(pfWaitUs);
  for(unsigned i=0;i<6;++i){
    if(i&&pfGapUs)delayMicroseconds(pfGapUs);
    auto& r=records[i];r.start=nowUs();
    regRead(pfReg[i],pfSub[i],r.raw,pfLen[i]);
    r.clock=SPI.getClockDivider();r.ctrl2=SPIporting::lastTransactionCtrl2();r.end=nowUs();
  }
  SPIporting::setProbeTiming(0,0,0);
}
static void postFaultCapture(){
  if(postFaultCaptured)return;
  postFaultCaptured=true;
  postReadSix(postFaultReads); // only six read transactions after existing TRXOFF
}
static bool postFaultCommand(uint32_t req,const char* op,char*& cur){
  if(!strcmp(op,"PFGAP")){
    if(tagRxFault||rxArmed||active||postBaselineCaptured||postFaultCaptured){ack(req,false,op,"FRESH_RXOFF_REQUIRED");return true;}
    uint32_t gap=0,wait=0;
    if(!parseU32(cur,gap)||!parseU32(cur,wait)||gap>1000||wait>1000){ack(req,false,op,"GAP_WAIT_0_TO_1000_US");return true;}
    while(*cur&&isspace((unsigned char)*cur))++cur;
    if(*cur){ack(req,false,op,"TWO_ARGS_ONLY");return true;}
    pfGapUs=gap;pfWaitUs=wait;
    event("{\"event\":\"ACK\",\"request\":%lu,\"op\":\"PFGAP\",\"ok\":true,\"gap_us\":%lu,\"wait_us\":%lu}",(unsigned long)req,(unsigned long)pfGapUs,(unsigned long)pfWaitUs);return true;
  }
  const bool baseline=!strcmp(op,"PFBASE"),info=!strcmp(op,"PFINFO");
  if(!baseline&&!info)return false;
  while(*cur&&isspace((unsigned char)*cur))++cur;
  if(*cur){ack(req,false,op,"NO_ARGS");return true;}
  if(baseline&&!postBaselineCaptured){
    if(tagRxFault||rxArmed||active||!hwOK){ack(req,false,op,"NEED_HEALTHY_RXOFF");return true;}
    postBaselineCaptured=true;
    DW1000Ng::forceTRxOff();
    postReadSix(postBaselineReads);
  }
  const bool captured=baseline?postBaselineCaptured:postFaultCaptured;
  const auto* records=baseline?postBaselineReads:postFaultReads;
  for(unsigned i=0;i<(captured?6U:0U);++i){
    const auto& r=records[i];
    event(R"json({"event":"ACK","request":%lu,"op":"PFREAD","ok":true,"baseline":%s,"idx":%u,"reg":%u,"sub":%u,"len":%u,"start_us":%llu,"end_us":%llu,"clock":%lu,"ctrl2":%lu,"raw_hex":"%02x%02x%02x%02x%02x"})json",
      (unsigned long)req,baseline?"true":"false",i,unsigned(pfReg[i]),unsigned(pfSub[i]),unsigned(pfLen[i]),(unsigned long long)r.start,(unsigned long long)r.end,(unsigned long)r.clock,(unsigned long)r.ctrl2,r.raw[0],r.raw[1],r.raw[2],r.raw[3],r.raw[4]);
  }
  event(R"json({"event":"ACK","request":%lu,"op":"%s","ok":true,"boot":%lu,"captured":%s,"count":%u,"after_trxoff":true,"latched":%s})json",(unsigned long)req,op,(unsigned long)bootId,captured?"true":"false",captured?6U:0U,tagRxFault?"true":"false");
  return true;
}
