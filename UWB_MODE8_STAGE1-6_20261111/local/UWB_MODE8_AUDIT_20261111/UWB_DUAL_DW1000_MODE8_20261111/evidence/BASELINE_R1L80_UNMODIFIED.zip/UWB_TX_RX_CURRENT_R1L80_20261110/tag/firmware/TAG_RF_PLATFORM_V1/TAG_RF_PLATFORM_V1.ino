// RF_PLATFORM_V1 complete measurement firmware.
// Runtime-controlled: modes 3/4/5/6/7, full CIR, timing, diagnostics, power plan, persistence, self-test.
void benchSetup();
void benchLoop();
void setup(){ benchSetup(); }
void loop(){ benchLoop(); }
