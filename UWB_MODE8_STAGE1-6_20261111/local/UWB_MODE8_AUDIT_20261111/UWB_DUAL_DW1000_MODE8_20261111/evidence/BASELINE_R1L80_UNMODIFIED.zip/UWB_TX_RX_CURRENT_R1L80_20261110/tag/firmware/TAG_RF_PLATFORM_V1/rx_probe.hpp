// Bounded standalone diagnostic. No TX, session start, NVS write, or guard reset.
// RXPROBE <request> <MHz 8|20> <delay 0|2> <gap_us 0..1000>
//         <rounds 1..32> <full_snapshot 0|1> <rx_on 0|1> <settle_us 0..10000>
static bool __attribute__((noinline)) rxProbeCommand(uint32_t req,const char* op,char*& cur){
  if(!strcmp(op,"SPIWRTEST")){
    uint32_t mhz,dm;
    if(!parseU32(cur,mhz)||!parseU32(cur,dm)||(mhz!=8&&mhz!=20)||(dm!=0&&dm!=2)){
      ack(req,false,op,"MHZ_8_20_DELAY_0_2_REQUIRED");return true;
    }
    while(*cur&&isspace((unsigned char)*cur))++cur;
    if(*cur||active||rxArmed||remaining||r03TagPointActive||r03TagAwaitCommit||tagRxFault||!hwOK){
      ack(req,false,op,"IDLE_HEALTHY_UNLATCHED_REQUIRED");return true;
    }
    // USR_SFD scratch test only with RX/TX off. Preserve bytes at baseline timing.
    uint8_t saved[20]{},confirm[20]{},pattern[20]{},readback[20]{};
    regRead(0x21,0,saved,20);regRead(0x21,0,confirm,20);
    if(memcmp(saved,confirm,20)){ack(req,false,op,"BASELINE_UNSTABLE_NO_WRITE");return true;}
    for(unsigned i=0;i<20;++i)pattern[i]=uint8_t(0x5aU^(i*37U));
    SPIporting::setProbeTiming(mhz*1000000,dm,0);
    regWrite(0x21,0,pattern,20);regRead(0x21,0,readback,20);
    bool matched=!memcmp(pattern,readback,20);
    const uint32_t clock=SPI.getClockDivider(),ctrl=SPIporting::lastTransactionCtrl2();
    SPIporting::setProbeTiming(0,0,0);SPIporting::setSPIspeed(SPIClock::FAST);
    regWrite(0x21,0,saved,20);regRead(0x21,0,confirm,20);
    bool restored=!memcmp(saved,confirm,20);
    if(!restored)tagGuardTrip(2,0,61);
    event(R"json({"event":"ACK","request":%lu,"op":"SPIWRTEST","ok":%s,"pattern_match":%s,"restore_verified":%s,"spi_clock":%lu,"spi_ctrl2":%lu,"rx_on":false})json",
      (unsigned long)req,matched&&restored?"true":"false",matched?"true":"false",restored?"true":"false",(unsigned long)clock,(unsigned long)ctrl);
    return true;
  }
  if(!strcmp(op,"RXSTEP")){
    while(*cur&&isspace((unsigned char)*cur))++cur;
    if(*cur||active||rxArmed||remaining||r03TagPointActive||r03TagAwaitCommit||tagRxFault||!hwOK){ack(req,false,op,"IDLE_HEALTHY_UNLATCHED_REQUIRED");return true;}
    static tagdiag::Record rr[3]; uint32_t count=0; int firstBad=-1;
    SPIporting::setProbeTiming(2000000,2,0);
    idleRadio();selectRoute(0);waitSwitch();
    auto sample=[&](unsigned i){auto& x=rr[i];x=tagDiagBase(62,1);x.detail=i;uint8_t b[4]{};regRead(0,0xFFFF,b,4);x.dev=le32(b);x.spi_clock=SPI.getClockDivider();x.spi_ctrl2=SPIporting::lastTransactionCtrl2();x.end_us=nowUs();x.bad=x.dev!=0xdeca0130UL;if(x.bad&&firstBad<0)firstBad=int(i);++count;};
    sample(0);
    uint64_t enabled=0,armed=0;uint32_t cmdClock=0,cmdCtrl=0;
    if(firstBad<0){
      DW1000Ng::startReceive();enabled=nowUs();cmdClock=SPI.getClockDivider();cmdCtrl=SPIporting::lastTransactionCtrl2();
      sample(1); // Hardware RX requested; software rxArmed is still false.
      rxArmed=true;armed=nowUs();
      sample(2); // Same explicit SPI override, software rxArmed now true.
    }
    if(firstBad>=0){tagDiag.push(rr[firstBad]);tagGuardTrip(2,0,62);}else{DW1000Ng::forceTRxOff();rxArmed=false;}
    SPIporting::setProbeTiming(0,0,0);SPIporting::setSPIspeed(SPIClock::FAST);
    for(uint32_t i=0;i<count;++i){uint32_t at=millis();while(outputPending.load()>2&&millis()-at<1000)delay(1);tagDiagEmit(req,i,rr[i]);}
    {uint32_t at=millis();while(outputPending.load()>2&&millis()-at<1000)delay(1);}
    event(R"json({"event":"ACK","request":%lu,"op":"RXSTEP","ok":%s,"count":%lu,"rx_enable_us":%llu,"rx_armed_us":%llu,"cmd_clock":%lu,"cmd_ctrl2":%lu,"guard_latched":%s})json",(unsigned long)req,firstBad<0?"true":"false",(unsigned long)count,(unsigned long long)enabled,(unsigned long long)armed,(unsigned long)cmdClock,(unsigned long)cmdCtrl,tagRxFault?"true":"false");
    return true;
  }
  if(strcmp(op,"RXPROBE"))return false;
  uint32_t mhz,dm,gap,n,full,on,settle;
  if(!parseU32(cur,mhz)||!parseU32(cur,dm)||!parseU32(cur,gap)||
     !parseU32(cur,n)||!parseU32(cur,full)||!parseU32(cur,on)||!parseU32(cur,settle)||
     (mhz!=2&&mhz!=8&&mhz!=20)||(dm!=0&&dm!=2)||gap>1000||n<1||n>10||full>1||on>1||settle>10000){
    ack(req,false,op,"INVALID_PROBE_ARGUMENTS");return true;
  }
  while(*cur&&isspace((unsigned char)*cur))++cur;
  if(*cur){ack(req,false,op,"EXTRA_ARGUMENT");return true;}
  if(active||rxArmed||remaining||r03TagPointActive||r03TagAwaitCommit||tagRxFault||!hwOK){
    ack(req,false,op,"IDLE_HEALTHY_UNLATCHED_REQUIRED");return true;
  }
  // All records stay in RAM until RX is off; serial output cannot change cadence.
  static tagdiag::Record records[32];uint32_t count=0;bool bad=false;
  SPIporting::setProbeTiming(mhz*1000000,dm,gap);
  idleRadio();selectRoute(0);waitSwitch();
  // Baseline uses the same diagnostic timing before issuing RXENAB.
  uint8_t base[4]{};regRead(0,0xFFFF,base,4);
  if(le32(base)!=0xdeca0130UL)bad=true;
  uint64_t enabled=nowUs();
  if(!bad&&on){DW1000Ng::startReceive();rxArmed=true;enabled=nowUs();}
  SPIporting::setProbeTiming(mhz*1000000,dm,gap);
  if(!bad&&settle)delayMicroseconds(settle);
  const bool baselineBad=bad; int firstBad=-1;
  for(uint32_t i=0;i<n&&!baselineBad;++i){
    auto& r=records[count++];r=tagDiagBase(60,1);r.detail=i;
    uint8_t d[4]{},a[5]{},b[5]{},tx[2]{},rx[2]{},st[5]{};
    if(full)regRead(6,0xFFFF,a,5);
    regRead(0,0xFFFF,d,4);r.dev=le32(d);
    if(full){
      regRead(0x18,0xFFFF,tx,2);
      regRead(0x2E,0x1804,rx,2);regRead(0x0F,0xFFFF,st,5);regRead(6,0xFFFF,b,5);
      r.time_a=le40(a);r.time_b=le40(b);r.tx=le16(tx);r.rx=le16(rx);r.status=le40(st);
      r.bad=!rxguard::goodSnapshot(r.dev,r.tx,r.rx,uint16_t(cfg.ant_tag),r.time_a,r.time_b)||!tagdiag::statusTrusted(r.status);
    }else r.bad=r.dev!=0xdeca0130UL;
    r.spi_clock=SPI.getClockDivider();r.spi_ctrl2=SPIporting::lastTransactionCtrl2();
    r.end_us=nowUs();if(r.bad && firstBad<0)firstBad=int(i);bad=bad||r.bad;
  }
  // Preserve first bad record before best-effort TRXOFF. Never auto-recover.
  if(bad){
    if(firstBad>=0)tagDiag.push(records[firstBad]);
    tagGuardTrip(2, firstBad>=0?records[firstBad].status:0,60);
  }else{DW1000Ng::forceTRxOff();rxArmed=false;}
  SPIporting::setProbeTiming(0,0,0);SPIporting::setSPIspeed(SPIClock::FAST);
  for(uint32_t i=0;i<count;++i){
    // RX is off: drain bounded output here, never during sampled transactions.
    uint32_t waitAt=millis();
    while(outputPending.load()>2 && millis()-waitAt<1000)delay(1);
    tagDiagEmit(req,i,records[i]);
  }
  {uint32_t waitAt=millis();while(outputPending.load()>2 && millis()-waitAt<1000)delay(1);}
  event(R"json({"event":"ACK","request":%lu,"op":"RXPROBE","ok":%s,"baseline_dev":%lu,"mhz":%lu,"delay":%lu,"gap_us":%lu,"rx_on":%lu,"full":%lu,"count":%lu,"rx_enable_us":%llu,"settle_us":%lu,"guard_latched":%s})json",
    (unsigned long)req,bad?"false":"true",(unsigned long)le32(base),(unsigned long)mhz,(unsigned long)dm,
    (unsigned long)gap,(unsigned long)on,(unsigned long)full,(unsigned long)count,(unsigned long long)enabled,
    (unsigned long)settle,tagRxFault?"true":"false");
  return true;
}

